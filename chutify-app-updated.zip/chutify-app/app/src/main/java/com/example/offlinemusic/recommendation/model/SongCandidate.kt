package com.example.offlinemusic.recommendation.model

/**
 * A song surfaced by the recommendation engine, before it's added to the
 * user's library/queue. Kept independent of the app's main Song/Track
 * model so this module has no compile-time dependency on it — map
 * SongCandidate -> your existing Song entity at the call site (Home
 * screen / player) once you wire this in.
 */
data class SongCandidate(
    val videoId: String,
    val title: String,
    val normalizedTitle: String,
    val artist: String,
    val normalizedArtist: String,
    val channelId: String,
    val channelTitle: String,
    val thumbnailUrl: String,
    val durationSeconds: Int? = null,
    val publishedAt: String? = null,
    // Not shown to users — just so you can see in logs why a song showed
    // up while tuning the ranker (e.g. "taste:Diljit Dosanjh", "trending-IN").
    val sourceReason: String = ""
)
