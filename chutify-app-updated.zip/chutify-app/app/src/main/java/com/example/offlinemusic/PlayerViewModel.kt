package com.example.offlinemusic

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.offlinemusic.home.HomeCardUi
import com.example.offlinemusic.home.YouTubeThumbnails
import com.example.offlinemusic.playback.NowPlayingInfo
import com.example.offlinemusic.playback.PlaybackService
import com.example.offlinemusic.playback.QueueNavigationListener
import com.example.offlinemusic.player.NowPlayingUi
import com.example.offlinemusic.player.PlayerUiState
import com.example.offlinemusic.playback.PlaybackServiceState
import com.example.offlinemusic.recommendation.model.SongCandidate
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Binds to PlaybackService, maps its state to PlayerUiState for the Player
 * module's composables, and does simple next/previous queue management —
 * a linear in-memory stack, not a persisted queue. Favorite status is also
 * in-memory only for now; no favorites table exists yet in any delivered
 * module, so this doesn't survive process death. Worth a real Room table
 * later if favorites need to persist.
 */
class PlayerViewModel(application: Application) : AndroidViewModel(application), QueueNavigationListener {

    private val container: AppContainer get() = (getApplication<Application>() as ChutifyApplication).container

    private var bound = false

    private val upcomingQueue = ArrayDeque<SongCandidate>()
    private val previousStack = ArrayDeque<SongCandidate>()
    private var currentCandidate: SongCandidate? = null

    private val _isFavorite = MutableStateFlow(false)
    private val serviceRef = MutableStateFlow<PlaybackService?>(null)
    private val service: PlaybackService? get() = serviceRef.value

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val localBinder = binder as PlaybackService.LocalBinder
            val svc = localBinder.getService()
            svc.setBackend(container.webViewPlayerBackend)
            svc.setQueueNavigationListener(this@PlayerViewModel)
            serviceRef.value = svc
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            serviceRef.value = null
        }
    }

    init {
        bindService()
    }

    private fun bindService() {
        val appContext = getApplication<Application>().applicationContext
        Intent(appContext, PlaybackService::class.java).also { intent ->
            appContext.startService(intent)
            appContext.bindService(intent, connection, Context.BIND_AUTO_CREATE)
            bound = true
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val uiState: StateFlow<PlayerUiState> = combine(
        serviceRef.flatMapLatest { it?.state ?: flowOf(PlaybackServiceState()) },
        _isFavorite
    ) { serviceState, isFavorite ->
        PlayerUiState(
            nowPlaying = serviceState.nowPlaying?.let {
                NowPlayingUi(it.videoId, it.title, it.artist, YouTubeThumbnails.url(it.videoId))
            },
            isPlaying = serviceState.isPlaying,
            positionMs = serviceState.positionMs,
            durationMs = serviceState.durationMs,
            isFavorite = isFavorite
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PlayerUiState())

    fun playCard(card: HomeCardUi) {
        val candidate = SongCandidate(
            videoId = card.id,
            title = card.title,
            normalizedTitle = card.title,
            artist = card.subtitle,
            normalizedArtist = card.subtitle,
            channelId = "",
            channelTitle = "",
            thumbnailUrl = card.imageUrl
        )
        playCandidate(candidate)
    }

    private fun playCandidate(candidate: SongCandidate) {
        currentCandidate?.let { previousStack.addFirst(it) }
        currentCandidate = candidate
        _isFavorite.value = false
        service?.updateNowPlaying(
            NowPlayingInfo(candidate.videoId, candidate.title, candidate.artist, durationMs = 0L),
            artworkBitmap = null // no Bitmap decode wired up here — the notification will show without artwork until that's added
        )
        viewModelScope.launch {
            container.recommendationEngine.recordPlay(candidate, msPlayed = 0L, completed = false, source = "ONLINE")
        }
        refillQueueIfNeeded(candidate)
    }

    private fun refillQueueIfNeeded(current: SongCandidate) {
        if (upcomingQueue.isNotEmpty()) return
        viewModelScope.launch {
            val related = container.recommendationEngine.getQueueForSong(current, limit = 15)
            upcomingQueue.addAll(related)
        }
    }

    fun togglePlayPause() {
        val playing = uiState.value.isPlaying
        if (playing) service?.pause() else service?.play()
    }

    fun skipNext() = onUserRequestedNext()
    fun skipPrevious() = onUserRequestedPrevious()

    override fun onUserRequestedNext() {
        val next = upcomingQueue.removeFirstOrNull()
        if (next != null) {
            playCandidate(next)
        } else {
            currentCandidate?.let { current ->
                viewModelScope.launch {
                    val related = container.recommendationEngine.getQueueForSong(current, limit = 15)
                    if (related.isNotEmpty()) {
                        upcomingQueue.addAll(related.drop(1))
                        playCandidate(related.first())
                    }
                }
            }
        }
    }

    override fun onUserRequestedPrevious() {
        val prev = previousStack.removeFirstOrNull() ?: return
        currentCandidate?.let { upcomingQueue.addFirst(it) }
        currentCandidate = prev
        service?.updateNowPlaying(NowPlayingInfo(prev.videoId, prev.title, prev.artist, durationMs = 0L), artworkBitmap = null)
    }

    override fun onTrackEndedNaturally() = onUserRequestedNext()

    fun seekTo(positionMs: Long) {
        service?.seekTo(positionMs)
    }

    fun toggleFavorite() {
        _isFavorite.value = !_isFavorite.value
    }

    override fun onCleared() {
        if (bound) {
            runCatching { getApplication<Application>().applicationContext.unbindService(connection) }
        }
        super.onCleared()
    }
}
