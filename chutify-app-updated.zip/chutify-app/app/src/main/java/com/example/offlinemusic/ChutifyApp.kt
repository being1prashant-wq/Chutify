package com.example.offlinemusic

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.weight
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.offlinemusic.home.HomeScreen
import com.example.offlinemusic.home.HomeViewModel
import com.example.offlinemusic.player.ExpandedPlayer
import com.example.offlinemusic.player.MiniPlayer
import com.example.offlinemusic.player.rememberPlayerSheetState
import com.example.offlinemusic.player.scaleWithPlayerSheet
import com.example.offlinemusic.ui.MusicUiTokens
import kotlinx.coroutines.launch

/**
 * Deliberately doesn't use the Player module's combined PlayerHost here —
 * PlayerHost bottom-aligns MiniPlayer over a fillMaxSize Box, which would
 * overlap it with BottomNavBar (both wanting the bottom edge). Placing
 * MiniPlayer directly in the Column, between the NavHost content and
 * BottomNavBar, keeps it correctly in-flow above the nav bar; ExpandedPlayer
 * still overlays everything as a separate full-screen layer when open.
 */
@Composable
fun ChutifyApp() {
    val showWelcome = remember { mutableStateOf(true) }
    if (showWelcome.value) {
        WelcomeScreen(onFinished = { showWelcome.value = false })
        return
    }

    val context = LocalContext.current
    val container = (context.applicationContext as ChutifyApplication).container
    val scope = rememberCoroutineScope()

    val navController = rememberNavController()
    val sheetState = rememberPlayerSheetState()
    val playerViewModel: PlayerViewModel = viewModel()
    val playerUiState by playerViewModel.uiState.collectAsState()
    val expansionProgress = sheetState.expansionProgress.value

    Surface(color = MusicUiTokens.Background, modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().scaleWithPlayerSheet(sheetState)) {
                Box(Modifier.weight(1f)) {
                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") {
                            val homeViewModel: HomeViewModel = viewModel(
                                factory = viewModelFactory {
                                    HomeViewModel(
                                        recommendationEngine = container.recommendationEngine,
                                        watchHistoryDao = container.database.watchHistoryDao(),
                                        userDisplayName = "Prashant"
                                    )
                                }
                            )
                            val homeState by homeViewModel.uiState.collectAsState()
                            HomeScreen(uiState = homeState, onCardClick = playerViewModel::playCard)
                        }
                        composable("new") { PlaceholderScreen("New") }
                        composable("search") { PlaceholderScreen("Search") }
                        composable("library") { PlaceholderScreen("Library") }
                    }
                }

                if (expansionProgress < 0.99f && playerUiState.nowPlaying != null) {
                    MiniPlayer(
                        state = playerUiState,
                        onTap = { scope.launch { sheetState.expand() } },
                        onPlayPause = playerViewModel::togglePlayPause,
                        onSkipNext = playerViewModel::skipNext
                    )
                }

                BottomNavBar(navController)
            }

            if (expansionProgress > 0.01f && playerUiState.nowPlaying != null) {
                ExpandedPlayer(
                    state = playerUiState,
                    sheetState = sheetState,
                    onPlayPause = playerViewModel::togglePlayPause,
                    onSkipNext = playerViewModel::skipNext,
                    onSkipPrevious = playerViewModel::skipPrevious,
                    onSeek = playerViewModel::seekTo,
                    onToggleFavorite = playerViewModel::toggleFavorite,
                    onOpenQueue = { /* QueueSheet from the queue module — one Boolean show/hide state here wires it in */ },
                    modifier = Modifier.graphicsLayer { alpha = expansionProgress }
                )
            }
        }
    }
}
