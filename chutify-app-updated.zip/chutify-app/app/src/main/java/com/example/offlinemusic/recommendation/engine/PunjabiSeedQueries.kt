package com.example.offlinemusic.recommendation.engine

/**
 * Cold-start seed queries — only used on first launch / while there's too
 * little history for a taste profile (see
 * TasteProfileEngine.MIN_PLAYS_FOR_WARM_START). Kept short since each
 * entry costs a 100-unit search.list call; CandidateGenerator.coldStartCandidates()
 * leans on the 1-unit trending chart for most of the load — this just adds
 * guaranteed Punjabi variety on top of whatever's generically trending.
 *
 * Cache the result for a day or two rather than re-running this list on
 * every cold-start check — see the README for the suggested TTL.
 */
object PunjabiSeedQueries {
    val SEED_ARTISTS = listOf(
        "Diljit Dosanjh",
        "AP Dhillon",
        "Karan Aujla",
        "Shubh",
        "Jassie Gill",
        "Sidhu Moose Wala"
    )
}
