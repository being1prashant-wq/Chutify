package com.example.offlinemusic.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media.app.NotificationCompat as MediaNotificationCompat
import androidx.media.session.MediaButtonReceiver
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

/**
 * Observable snapshot of what PlaybackService is doing — added during
 * assembly so the UI layer (PlayerViewModel) has something to collect
 * instead of needing its own separate listener on the backend (which would
 * clash with the one PlaybackService itself installs via setBackend()).
 */
data class PlaybackServiceState(
    val nowPlaying: NowPlayingInfo? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L
)

/**
 * Foreground Service that keeps audio alive when the app is backgrounded or
 * the screen is locked, and drives the notification + lock-screen controls.
 *
 * Built on MediaSessionCompat rather than Media3's MediaSessionService on
 * purpose: Media3's Player interface (~50 methods — timeline, track
 * selection, media item queue...) is shaped around ExoPlayer-style
 * backends and is a lot of surface area to fake for a WebView-driven
 * player. MediaSessionCompat only cares about play/pause/seek/metadata,
 * which is what this app's actual backend needs. If Chutify ever moves to
 * a native ExoPlayer pipeline for a legitimately-sourced audio stream,
 * Media3's MediaSessionService becomes the better fit then — not now.
 *
 * NOTE ON PACKAGE NAMES: MediaSessionCompat / MediaMetadataCompat /
 * PlaybackStateCompat live under android.support.v4.media.* even though
 * they ship in the androidx.media artifact — androidx never renamed those
 * specific classes during the Jetpack migration. MediaButtonReceiver and
 * the MediaStyle notification helper did get renamed, to androidx.media.*.
 * Both are correct as imported below, not a typo.
 *
 * IMPORTANT — WebView background throttling: Chromium, which is what
 * actually renders/plays the YouTube IFrame inside the invisible WebView,
 * throttles JS timers and can suspend playback once its WebView is no
 * longer attached to a visible window — regardless of this service running
 * in the foreground. This service does what's in its power (wake lock,
 * surviving process death via START_STICKY), but wherever the Activity
 * currently manages the WebView's lifecycle needs to stop calling
 * onPause()/pauseTimers() on it while a song should keep playing — see the
 * README. Some OEM battery optimizers (MIUI, ColorOS, Funtouch) kill
 * background audio regardless of correct code; that's a device setting the
 * user has to allow, not something fixable purely in-app.
 */
class PlaybackService : Service() {

    companion object {
        const val CHANNEL_ID = "chutify_playback"
        const val NOTIFICATION_ID = 1001
        const val ACTION_PLAY = "com.example.offlinemusic.playback.PLAY"
        const val ACTION_PAUSE = "com.example.offlinemusic.playback.PAUSE"
        const val ACTION_NEXT = "com.example.offlinemusic.playback.NEXT"
        const val ACTION_PREVIOUS = "com.example.offlinemusic.playback.PREVIOUS"

        private const val PLAYBACK_ACTIONS =
            PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or
                PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or PlaybackStateCompat.ACTION_SEEK_TO
    }

    inner class LocalBinder : Binder() {
        fun getService(): PlaybackService = this@PlaybackService
    }
    private val binder = LocalBinder()

    private val _state = MutableStateFlow(PlaybackServiceState())
    val state: StateFlow<PlaybackServiceState> = _state

    private var backend: PlayerBackend? = null
    private var queueNavigationListener: QueueNavigationListener? = null
    private var nowPlaying: NowPlayingInfo? = null
    private var artwork: Bitmap? = null

    private lateinit var mediaSession: MediaSessionCompat
    private lateinit var audioManager: AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private val becomingNoisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
                pause() // headphones unplugged — don't blast the speaker
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        mediaSession = MediaSessionCompat(this, "ChutifyPlaybackService").apply {
            setCallback(mediaSessionCallback)
            setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or
                    MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS
            )
            isActive = true
        }

        createNotificationChannel()
        ContextCompat.registerReceiver(
            this,
            becomingNoisyReceiver,
            IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        MediaButtonReceiver.handleIntent(mediaSession, intent)
        when (intent?.action) {
            ACTION_PLAY -> play()
            ACTION_PAUSE -> pause()
            ACTION_NEXT -> queueNavigationListener?.onUserRequestedNext()
            ACTION_PREVIOUS -> queueNavigationListener?.onUserRequestedPrevious()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        releaseWakeLock()
        abandonAudioFocus()
        runCatching { unregisterReceiver(becomingNoisyReceiver) }
        mediaSession.release()
        backend?.release()
        super.onDestroy()
    }

    // ---- Public API — call these from the ViewModel that binds to this service ----

    fun setBackend(newBackend: PlayerBackend) {
        backend = newBackend
        newBackend.setListener(object : PlayerBackendListener {
            override fun onPlaybackStateChanged(isPlaying: Boolean) {
                pushPlaybackState(isPlaying, backend?.currentPositionMs ?: 0L)
                refreshNotification(isPlaying)
                if (isPlaying) acquireWakeLock() else releaseWakeLock()
                _state.update { it.copy(isPlaying = isPlaying) }
            }
            override fun onPositionChanged(positionMs: Long, durationMs: Long) {
                // Just the MediaSession state — the system interpolates the
                // lock-screen/notification seek bar from position + speed,
                // no need to rebuild the Notification object every tick.
                pushPlaybackState(backend?.isPlaying ?: false, positionMs)
                _state.update { it.copy(positionMs = positionMs, durationMs = durationMs) }
            }
            override fun onTrackEnded() {
                queueNavigationListener?.onTrackEndedNaturally()
            }
            override fun onError(message: String) {
                pause()
            }
        })
    }

    fun setQueueNavigationListener(listener: QueueNavigationListener) {
        queueNavigationListener = listener
    }

    /** Call whenever the app switches to a new song — from the queue, taste engine, wherever. */
    fun updateNowPlaying(info: NowPlayingInfo, artworkBitmap: Bitmap?) {
        nowPlaying = info
        artwork = artworkBitmap
        mediaSession.setMetadata(buildMetadata(info, artworkBitmap))
        backend?.loadAndPlay(info.videoId)
        startForeground(NOTIFICATION_ID, buildNotification(isPlaying = true))
        _state.update { it.copy(nowPlaying = info, isPlaying = true, positionMs = 0L, durationMs = info.durationMs) }
    }

    fun play() {
        if (requestAudioFocus()) backend?.play()
    }

    fun pause() {
        backend?.pause()
    }

    fun seekTo(positionMs: Long) {
        backend?.seekTo(positionMs)
    }

    /** Full stop — not just pause. Drops the notification and lets the service die. */
    fun stopPlaybackAndService() {
        backend?.pause()
        releaseWakeLock()
        abandonAudioFocus()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---- Internals ----

    private val mediaSessionCallback = object : MediaSessionCompat.Callback() {
        override fun onPlay() = play()
        override fun onPause() = pause()
        override fun onSkipToNext() { queueNavigationListener?.onUserRequestedNext() }
        override fun onSkipToPrevious() { queueNavigationListener?.onUserRequestedPrevious() }
        override fun onSeekTo(pos: Long) = seekTo(pos)
    }

    private fun requestAudioFocus(): Boolean {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener { change ->
                when (change) {
                    AudioManager.AUDIOFOCUS_LOSS, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> pause()
                    AudioManager.AUDIOFOCUS_GAIN -> backend?.play()
                }
            }
            .build()
        audioFocusRequest = request
        return audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        // minSdk < 26 project: swap this whole method for the older
        // audioManager.requestAudioFocus(listener, STREAM_MUSIC, AUDIOFOCUS_GAIN) overload.
    }

    private fun abandonAudioFocus() {
        audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Chutify:PlaybackWakeLock").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 1000L) // safety timeout so a missed release() can't pin it forever
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun pushPlaybackState(isPlaying: Boolean, positionMs: Long) {
        val state = if (isPlaying) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED
        mediaSession.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(PLAYBACK_ACTIONS)
                .setState(state, positionMs, if (isPlaying) 1f else 0f)
                .build()
        )
    }

    private fun refreshNotification(isPlaying: Boolean) {
        // startForeground() is safe to call again with updated content — it
        // both creates and updates the ongoing notification.
        startForeground(NOTIFICATION_ID, buildNotification(isPlaying))
    }

    private fun buildMetadata(info: NowPlayingInfo, artworkBitmap: Bitmap?): MediaMetadataCompat {
        return MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, info.title)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, info.artist)
            .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, info.durationMs)
            .apply { artworkBitmap?.let { putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, it) } }
            .build()
    }

    private fun buildNotification(isPlaying: Boolean): Notification {
        val info = nowPlaying
        val playPauseAction = if (isPlaying) {
            NotificationCompat.Action(android.R.drawable.ic_media_pause, "Pause", actionPendingIntent(ACTION_PAUSE))
        } else {
            NotificationCompat.Action(android.R.drawable.ic_media_play, "Play", actionPendingIntent(ACTION_PLAY))
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play) // swap for the app's own notification icon
            .setContentTitle(info?.title ?: "")
            .setContentText(info?.artist ?: "")
            .setLargeIcon(artwork)
            .setOnlyAlertOnce(true)
            .setOngoing(isPlaying)
            .addAction(android.R.drawable.ic_media_previous, "Previous", actionPendingIntent(ACTION_PREVIOUS))
            .addAction(playPauseAction)
            .addAction(android.R.drawable.ic_media_next, "Next", actionPendingIntent(ACTION_NEXT))
            .setStyle(
                MediaNotificationCompat.MediaStyle()
                    .setMediaSession(mediaSession.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun actionPendingIntent(action: String): PendingIntent {
        val intent = Intent(this, PlaybackService::class.java).setAction(action)
        return PendingIntent.getService(
            this, action.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Playback", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Now playing controls" }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }
}
