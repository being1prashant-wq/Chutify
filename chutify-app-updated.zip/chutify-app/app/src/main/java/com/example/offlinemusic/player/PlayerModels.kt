package com.example.offlinemusic.player

data class NowPlayingUi(
    val videoId: String,
    val title: String,
    val artist: String,
    val artworkUrl: String
)

data class PlayerUiState(
    val nowPlaying: NowPlayingUi? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isFavorite: Boolean = false
)
