package com.example.offlinemusic.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Shared across the home and player modules — this supersedes the
 * MusicUiTokens.kt delivered with the Home screen module (which lived at
 * com.example.offlinemusic.home.MusicUiTokens). When integrating both:
 * delete that copy, move this one to a `ui` package, and update Home's
 * imports to point here instead. Sorry for the churn — wasn't obvious
 * this needed to be shared until Player needed the same tokens too.
 *
 * Colors are close approximations read off the reference screenshots, not
 * pixel-sampled — nudge these once rendered. If the project already has
 * MaterialTheme color tokens set up, prefer those and delete this file
 * instead.
 */
object MusicUiTokens {
    val Background = Color(0xFF000000)
    val PrimaryText = Color(0xFFFFFFFF)
    val SecondaryText = Color(0xFFA0A0A5)
    val Accent = Color(0xFFFC3C44) // Apple Music red, approximate
    val MiniPlayerBackground = Color(0xFF1E1E20)
    val Divider = Color(0xFF2C2C2E)

    val ScreenPadding = 16.dp
    val SmallCardCorner = 8.dp
    val LargeCardCorner = 16.dp
}
