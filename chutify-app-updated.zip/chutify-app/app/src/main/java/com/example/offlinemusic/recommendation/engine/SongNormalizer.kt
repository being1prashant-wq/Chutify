package com.example.offlinemusic.recommendation.engine

import java.util.Locale

/**
 * Turns a raw YouTube video title into (artist, cleanTitle) plus a
 * normalized dedup key — the same song re-uploaded under a different
 * videoId (different channel, re-encode, lyric-video reupload, etc.)
 * should still be recognised as a duplicate, per the existing
 * normalized-metadata requirement.
 */
object SongNormalizer {

    private val NOISE_PATTERNS = listOf(
        "official video", "official audio", "official music video", "lyric video",
        "lyrics", "audio", "full video", "full song", "hd", "4k", "hq",
        "official", "video", "new punjabi song", "latest punjabi song",
        "punjabi song", "new song"
    )

    private val BRACKETS_REGEX = Regex("""[(\[{][^)\]}]*[)\]}]""")
    private val FEATURING_REGEX = Regex("""\b(feat\.?|ft\.?|featuring)\b.*""", RegexOption.IGNORE_CASE)
    private val NON_ALNUM_REGEX = Regex("""[^a-z0-9 ]""")
    private val MULTI_SPACE_REGEX = Regex("""\s+""")

    /** "Artist - Song Title (Official Video)" -> Artist to "Song Title", best-effort. */
    fun splitArtistAndTitle(rawTitle: String, fallbackChannelTitle: String): Pair<String, String> {
        val withoutBrackets = rawTitle.replace(BRACKETS_REGEX, " ")
        val parts = withoutBrackets.split(" - ", " – ", " — ", limit = 2)
        return if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
            parts[0].trim() to parts[1].trim()
        } else {
            // Many artist channels just post "Song Title" with the artist
            // implied by the channel name — fall back to that.
            val cleanedChannel = fallbackChannelTitle
                .removeSuffix("VEVO").removeSuffix("Vevo")
                .removeSuffix(" Official").removeSuffix(" Music").trim()
            cleanedChannel.ifBlank { "Unknown" } to withoutBrackets.trim()
        }
    }

    fun normalize(text: String): String {
        var t = text.lowercase(Locale.ROOT)
        t = t.replace(BRACKETS_REGEX, " ")
        t = t.replace(FEATURING_REGEX, " ")
        NOISE_PATTERNS.forEach { t = t.replace(it, " ") }
        t = t.replace(NON_ALNUM_REGEX, " ")
        t = t.replace(MULTI_SPACE_REGEX, " ").trim()
        return t
    }

    /** ISO-8601 duration ("PT3M45S") -> total seconds. Null if unparsable. */
    fun parseIsoDurationToSeconds(iso: String?): Int? {
        if (iso.isNullOrBlank()) return null
        val regex = Regex("""PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?""")
        val match = regex.matchEntire(iso) ?: return null
        val (h, m, s) = match.destructured
        return (h.toIntOrNull() ?: 0) * 3600 + (m.toIntOrNull() ?: 0) * 60 + (s.toIntOrNull() ?: 0)
    }

    /**
     * For LIBRARY-level duplicate detection (e.g. before adding a fetched
     * candidate to the user's saved library) — includes duration so two
     * different songs that happen to share a title/artist don't collide.
     * Not the same key WatchHistoryDao.recentlyPlayedKeys() uses for
     * "don't repeat this too soon" in the ranker; that one is artist+title
     * only, on purpose — see SongRanker.
     */
    fun dedupeKey(normalizedTitle: String, normalizedArtist: String, durationSeconds: Int?): String {
        val bucketedDuration = durationSeconds?.let { (it / 5) * 5 } ?: -1 // 5s buckets absorb re-encodes
        return "$normalizedArtist|$normalizedTitle|$bucketedDuration"
    }
}
