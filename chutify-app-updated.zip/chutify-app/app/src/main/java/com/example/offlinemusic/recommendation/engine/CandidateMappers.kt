package com.example.offlinemusic.recommendation.engine

import com.example.offlinemusic.recommendation.model.SongCandidate
import com.example.offlinemusic.recommendation.network.PlaylistItem
import com.example.offlinemusic.recommendation.network.SearchItem
import com.example.offlinemusic.recommendation.network.VideoItem

internal fun SearchItem.toCandidate(reason: String): SongCandidate? {
    val videoId = id.videoId ?: return null
    val (artist, title) = SongNormalizer.splitArtistAndTitle(snippet.title, snippet.channelTitle ?: "")
    return SongCandidate(
        videoId = videoId,
        title = title,
        normalizedTitle = SongNormalizer.normalize(title),
        artist = artist,
        normalizedArtist = SongNormalizer.normalize(artist),
        channelId = snippet.channelId,
        channelTitle = snippet.channelTitle ?: "",
        thumbnailUrl = snippet.thumbnails?.medium?.url ?: snippet.thumbnails?.default?.url ?: "",
        publishedAt = snippet.publishedAt,
        sourceReason = reason
    )
}

internal fun VideoItem.toCandidate(reason: String): SongCandidate {
    val (artist, title) = SongNormalizer.splitArtistAndTitle(snippet.title, snippet.channelTitle ?: "")
    return SongCandidate(
        videoId = id,
        title = title,
        normalizedTitle = SongNormalizer.normalize(title),
        artist = artist,
        normalizedArtist = SongNormalizer.normalize(artist),
        channelId = snippet.channelId,
        channelTitle = snippet.channelTitle ?: "",
        thumbnailUrl = snippet.thumbnails?.medium?.url ?: snippet.thumbnails?.default?.url ?: "",
        durationSeconds = SongNormalizer.parseIsoDurationToSeconds(contentDetails?.duration),
        publishedAt = snippet.publishedAt,
        sourceReason = reason
    )
}

internal fun PlaylistItem.toCandidate(reason: String): SongCandidate? {
    val videoId = snippet.resourceId.videoId ?: return null
    val (artist, title) = SongNormalizer.splitArtistAndTitle(snippet.title, snippet.channelTitle ?: "")
    return SongCandidate(
        videoId = videoId,
        title = title,
        normalizedTitle = SongNormalizer.normalize(title),
        artist = artist,
        normalizedArtist = SongNormalizer.normalize(artist),
        channelId = snippet.channelId,
        channelTitle = snippet.channelTitle ?: "",
        thumbnailUrl = snippet.thumbnails?.medium?.url ?: snippet.thumbnails?.default?.url ?: "",
        publishedAt = snippet.publishedAt,
        sourceReason = reason
    )
}
