package com.example.offlinemusic.recommendation.network

import kotlinx.serialization.Serializable

// Written for kotlinx.serialization. If the project uses Moshi/Gson
// instead, drop @Serializable and swap in the equivalent annotations —
// field names already match the raw JSON so no renaming is needed.

@Serializable
data class YouTubeSearchResponse(val items: List<SearchItem> = emptyList())

@Serializable
data class SearchItem(val id: SearchItemId, val snippet: Snippet)

@Serializable
data class SearchItemId(val videoId: String? = null)

@Serializable
data class YouTubeVideosResponse(val items: List<VideoItem> = emptyList())

@Serializable
data class VideoItem(
    val id: String,
    val snippet: Snippet,
    val contentDetails: ContentDetails? = null
)

@Serializable
data class ContentDetails(val duration: String? = null) // ISO 8601, e.g. "PT3M45S"

@Serializable
data class YouTubePlaylistItemsResponse(val items: List<PlaylistItem> = emptyList())

@Serializable
data class PlaylistItem(val snippet: PlaylistSnippet)

@Serializable
data class PlaylistSnippet(
    val title: String,
    val channelId: String,
    val channelTitle: String? = null,
    val publishedAt: String? = null,
    val thumbnails: Thumbnails? = null,
    val resourceId: ResourceId
)

@Serializable
data class ResourceId(val videoId: String? = null)

@Serializable
data class Snippet(
    val title: String,
    val channelId: String,
    val channelTitle: String? = null,
    val publishedAt: String? = null,
    val thumbnails: Thumbnails? = null
)

@Serializable
data class Thumbnails(val medium: Thumbnail? = null, val default: Thumbnail? = null)

@Serializable
data class Thumbnail(val url: String)

@Serializable
data class YouTubeChannelsResponse(val items: List<ChannelItem> = emptyList())

@Serializable
data class ChannelItem(val contentDetails: ChannelContentDetails)

@Serializable
data class ChannelContentDetails(val relatedPlaylists: RelatedPlaylists)

@Serializable
data class RelatedPlaylists(val uploads: String)
