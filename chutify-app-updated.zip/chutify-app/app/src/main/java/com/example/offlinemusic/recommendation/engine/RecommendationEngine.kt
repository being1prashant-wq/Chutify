package com.example.offlinemusic.recommendation.engine

import com.example.offlinemusic.recommendation.data.WatchHistoryDao
import com.example.offlinemusic.recommendation.model.SongCandidate
import com.example.offlinemusic.recommendation.model.WatchHistoryEntity

/**
 * Public entry point — the only class the rest of the app should need to
 * call. Wire it up once (DI graph / a singleton) with a Retrofit-backed
 * YouTubeMusicApi and the WatchHistoryDao from your existing Room database.
 *
 *   val engine = RecommendationEngine(
 *       dao = db.watchHistoryDao(),
 *       tasteProfileEngine = TasteProfileEngine(db.watchHistoryDao()),
 *       candidateGenerator = CandidateGenerator(youTubeMusicApi, apiKey, quotaGuard),
 *       ranker = SongRanker()
 *   )
 */
class RecommendationEngine(
    private val dao: WatchHistoryDao,
    private val tasteProfileEngine: TasteProfileEngine,
    private val candidateGenerator: CandidateGenerator,
    private val ranker: SongRanker
) {

    /** Home screen feed. Random-ish trending Punjabi on first use, taste-based after. */
    suspend fun getHomeRecommendations(limit: Int = 30): List<SongCandidate> {
        val profile = tasteProfileEngine.buildProfile()
        val candidates = candidateGenerator.homeCandidates(profile)
        return ranker.rank(candidates, profile, recentlyPlayedDedupeKeys(), limit)
    }

    /** Upcoming-queue songs related to whatever's currently playing. */
    suspend fun getQueueForSong(current: SongCandidate, limit: Int = 20): List<SongCandidate> {
        val profile = tasteProfileEngine.buildProfile()
        val candidates = candidateGenerator.queueCandidates(current.channelId, current.artist)
            .filterNot { it.videoId == current.videoId }
        // maxPerArtist relaxed vs. Home: a same-artist queue right after a
        // song by that artist is exactly what's expected here.
        return ranker.rank(candidates, profile, recentlyPlayedDedupeKeys(), limit, maxPerArtist = limit)
    }

    /** Call this from the player whenever a song starts/finishes so the taste profile stays current. */
    suspend fun recordPlay(song: SongCandidate, msPlayed: Long, completed: Boolean, source: String) {
        dao.recordPlay(
            WatchHistoryEntity(
                videoId = song.videoId,
                title = song.title,
                normalizedTitle = song.normalizedTitle,
                artist = song.artist,
                normalizedArtist = song.normalizedArtist,
                channelId = song.channelId,
                channelTitle = song.channelTitle,
                durationSeconds = song.durationSeconds ?: 0,
                playedAtEpochMillis = System.currentTimeMillis(),
                msPlayed = msPlayed,
                completed = completed,
                source = source
            )
        )
    }

    private suspend fun recentlyPlayedDedupeKeys(): Set<String> {
        val sinceMillis = System.currentTimeMillis() - 3L * 24 * 60 * 60 * 1000 // last 3 days
        return dao.recentlyPlayedKeys(sinceMillis).toSet()
    }
}
