package com.example.offlinemusic.playback

/**
 * What PlaybackService needs from whatever is actually producing sound.
 * Written against the existing WebView + YouTube IFrame Player API setup
 * (the 2dp-invisible-WebView approach already in the app) but kept
 * backend-agnostic on purpose — wrap the existing WebView controller in a
 * class implementing this (see WebViewPlayerBackendExample.kt for the
 * shape). PlaybackService never touches the WebView directly, so this
 * still works if the backend ever changes later.
 */
interface PlayerBackend {
    val isPlaying: Boolean
    val currentPositionMs: Long
    val durationMs: Long

    fun loadAndPlay(videoId: String)
    fun play()
    fun pause()
    fun seekTo(positionMs: Long)
    fun release()
    fun setListener(listener: PlayerBackendListener)
}

interface PlayerBackendListener {
    fun onPlaybackStateChanged(isPlaying: Boolean)
    fun onPositionChanged(positionMs: Long, durationMs: Long)
    fun onTrackEnded()
    fun onError(message: String)
}

/** Notification/MediaSession metadata — independent of the app's Song model on purpose. */
data class NowPlayingInfo(
    val videoId: String,
    val title: String,
    val artist: String,
    val durationMs: Long
)

/**
 * The service knows how to play/pause/seek, but not what "next song" means
 * — that's the app's queue (the ModalBottomSheet queue already built).
 * Implement this in whichever ViewModel owns the queue and register it via
 * PlaybackService.setQueueNavigationListener(...).
 */
interface QueueNavigationListener {
    fun onUserRequestedNext()
    fun onUserRequestedPrevious()
    fun onTrackEndedNaturally()
}
