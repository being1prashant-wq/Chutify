package com.example.offlinemusic.recommendation.network

import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Thin Retrofit wrapper around just the YouTube Data API v3 endpoints the
 * recommendation engine needs. Assumes a Retrofit instance already exists
 * elsewhere in the app for the "Online tab" trending sections — point that
 * same client at base URL "https://www.googleapis.com/youtube/v3/" and add
 * this interface to it rather than standing up a second client.
 *
 * Quota cost per call (2026 pricing): search = 100 units, everything else
 * here = 1 unit. There's no relatedToVideoId search param anymore (Google
 * deprecated it in August 2023) — same-artist candidates come from
 * playlistItems/channel below instead, which also happens to be 100x cheaper.
 */
interface YouTubeMusicApi {

    // 100 units — gate every call behind SearchQuotaGuard.canSearch()
    @GET("search")
    suspend fun search(
        @Query("q") query: String,
        @Query("part") part: String = "snippet",
        @Query("type") type: String = "video",
        @Query("videoCategoryId") videoCategoryId: String = "10", // Music
        @Query("maxResults") maxResults: Int = 15,
        @Query("regionCode") regionCode: String = "IN",
        @Query("key") apiKey: String
    ): YouTubeSearchResponse

    // 1 unit — batch up to 50 IDs in a single call
    @GET("videos")
    suspend fun videos(
        @Query("id") commaSeparatedIds: String,
        @Query("part") part: String = "snippet,contentDetails",
        @Query("key") apiKey: String
    ): YouTubeVideosResponse

    // 1 unit — trending Indian music chart, the main cold-start source
    @GET("videos")
    suspend fun mostPopularMusic(
        @Query("chart") chart: String = "mostPopular",
        @Query("videoCategoryId") videoCategoryId: String = "10",
        @Query("regionCode") regionCode: String = "IN",
        @Query("part") part: String = "snippet,contentDetails",
        @Query("maxResults") maxResults: Int = 25,
        @Query("key") apiKey: String
    ): YouTubeVideosResponse

    // 1 unit — resolve a channel's uploads playlist ID (cached after first call)
    @GET("channels")
    suspend fun channel(
        @Query("id") channelId: String,
        @Query("part") part: String = "contentDetails",
        @Query("key") apiKey: String
    ): YouTubeChannelsResponse

    // 1 unit — same-artist candidates without touching search.list at all
    @GET("playlistItems")
    suspend fun playlistItems(
        @Query("playlistId") playlistId: String,
        @Query("part") part: String = "snippet,contentDetails",
        @Query("maxResults") maxResults: Int = 25,
        @Query("key") apiKey: String
    ): YouTubePlaylistItemsResponse
}
