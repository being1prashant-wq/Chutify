package com.example.offlinemusic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Plain darkColorScheme() as a safe baseline — build a real
            // Theme.kt around MusicUiTokens later if more Material3
            // theming (typography scale, etc.) is wanted app-wide.
            MaterialTheme(colorScheme = darkColorScheme()) {
                ChutifyApp()
            }
        }
    }
}
