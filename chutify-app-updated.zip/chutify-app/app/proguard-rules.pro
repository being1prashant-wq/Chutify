# Add project specific ProGuard rules here.
# Release builds have minification disabled (isMinifyEnabled = false) for
# now, so this file isn't doing anything yet — kept as a placeholder for
# when that changes. If minification gets turned on, YouTubeDtos.kt's
# kotlinx.serialization data classes will need keep rules; see
# https://github.com/Kotlin/kotlinx.serialization for the current ones.
