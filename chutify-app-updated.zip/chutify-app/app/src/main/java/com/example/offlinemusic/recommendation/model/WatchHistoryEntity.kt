package com.example.offlinemusic.recommendation.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One play event. Deliberately denormalized (its own copy of title/artist/
 * duration, not just a foreign key) so:
 *  1. Duplicate-song detection can use normalized title/artist/duration
 *     directly, per the existing "not just video ID" requirement — a
 *     re-upload of the same song under a new videoId still matches.
 *  2. This table doesn't break if your main library schema changes later.
 *
 * INTEGRATION: add WatchHistoryEntity::class to your existing @Database's
 * entities list and bump the schema version. No need for a second Room
 * database — one app, one DB.
 */
@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val videoId: String,
    val title: String,
    val normalizedTitle: String,
    val artist: String,
    val normalizedArtist: String,
    val channelId: String,
    val channelTitle: String,
    val durationSeconds: Int,
    val playedAtEpochMillis: Long,
    val msPlayed: Long,
    val completed: Boolean,
    val source: String // "ONLINE" | "OFFLINE" — mirrors the existing tabs
)
