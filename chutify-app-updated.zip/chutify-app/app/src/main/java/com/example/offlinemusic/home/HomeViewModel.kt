package com.example.offlinemusic.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.offlinemusic.recommendation.data.WatchHistoryDao
import com.example.offlinemusic.recommendation.engine.RecommendationEngine
import com.example.offlinemusic.recommendation.model.SongCandidate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Populates HomeUiState from the recommendation-engine module built
 * earlier. The section-to-data mapping below is a heuristic, not real
 * editorial curation — there's no curation team behind a YouTube-only app,
 * so this leans on SongCandidate.sourceReason (already tagged by
 * CandidateGenerator: "taste:<artist>", "trending-IN", "seed:<artist>") to
 * bucket results into something that reads like the reference layout
 * without pretending to be editorially curated the way Apple's own
 * "Apple Music Pop"-style playlists are — those labels/branding aren't
 * reproduced here on purpose.
 */
class HomeViewModel(
    private val recommendationEngine: RecommendationEngine,
    private val watchHistoryDao: WatchHistoryDao,
    private val userDisplayName: String? = null // for "<Name>'s Station" — falls back to a generic label if null
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState(isLoading = true))
    val uiState: StateFlow<HomeUiState> = _uiState

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            runCatching {
                val moreLike = buildMoreLikeSection()
                val candidates = recommendationEngine.getHomeRecommendations(limit = 40)
                val recentlyPlayed = buildRecentlyPlayedSection()
                buildSections(moreLike, candidates, recentlyPlayed)
            }.onSuccess { sections ->
                _uiState.update { it.copy(sections = sections, isLoading = false) }
            }.onFailure { e ->
                _uiState.update { it.copy(isLoading = false, errorMessage = e.message ?: "Couldn't load Home") }
            }
        }
    }

    private suspend fun buildMoreLikeSection(): HomeSection? {
        val mostRecent = watchHistoryDao.recent(limit = 1).firstOrNull() ?: return null
        val seed = SongCandidate(
            videoId = mostRecent.videoId,
            title = mostRecent.title,
            normalizedTitle = mostRecent.normalizedTitle,
            artist = mostRecent.artist,
            normalizedArtist = mostRecent.normalizedArtist,
            channelId = mostRecent.channelId,
            channelTitle = mostRecent.channelTitle,
            thumbnailUrl = YouTubeThumbnails.url(mostRecent.videoId)
        )
        val related = recommendationEngine.getQueueForSong(seed, limit = 10)
        if (related.isEmpty()) return null
        return HomeSection(
            id = "more-like",
            header = HomeSectionHeader(eyebrow = "More Like", title = mostRecent.title, imageUrl = seed.thumbnailUrl),
            style = HomeSectionStyle.SMALL_CAROUSEL,
            cards = related.map { it.toCard() }
        )
    }

    private suspend fun buildRecentlyPlayedSection(): HomeSection? {
        val recent = watchHistoryDao.recent(limit = 15).distinctBy { it.videoId }
        if (recent.isEmpty()) return null
        return HomeSection(
            id = "recently-played",
            header = HomeSectionHeader(title = "Recently Played"),
            style = HomeSectionStyle.SMALL_CAROUSEL,
            cards = recent.map {
                HomeCardUi(id = it.videoId, title = it.title, subtitle = it.artist, imageUrl = YouTubeThumbnails.url(it.videoId))
            }
        )
    }

    private fun buildSections(
        moreLike: HomeSection?,
        candidates: List<SongCandidate>,
        recentlyPlayed: HomeSection?
    ): List<HomeSection> {
        val byTaste = candidates.filter { it.sourceReason.startsWith("taste:") }
        val trending = candidates.filter { it.sourceReason == "trending-IN" }
        val seeded = candidates.filter { it.sourceReason.startsWith("seed:") }

        val sections = mutableListOf<HomeSection>()
        moreLike?.let { sections += it }

        byTaste.groupBy { it.artist }.entries.firstOrNull()?.let { (artist, songs) ->
            sections += HomeSection(
                id = "more-from-$artist",
                header = HomeSectionHeader(eyebrow = "More From", title = artist, imageShape = HeaderImageShape.CIRCLE, imageUrl = songs.first().thumbnailUrl),
                style = HomeSectionStyle.SMALL_CAROUSEL,
                cards = songs.map { it.toCard() }
            )
        }

        if (trending.isNotEmpty()) {
            sections += HomeSection(
                id = "top-picks",
                header = HomeSectionHeader(title = "Top Picks for You", showChevron = false),
                style = HomeSectionStyle.LARGE_FEATURE_ROW,
                cards = trending.take(6).map { it.toCard(badge = "Made for You") }
            )
        }

        recentlyPlayed?.let { sections += it }

        if (byTaste.isNotEmpty()) {
            sections += HomeSection(
                id = "playlists-for-you",
                header = HomeSectionHeader(title = "Playlists Made for You", showChevron = false),
                style = HomeSectionStyle.LARGE_FEATURE_ROW,
                cards = byTaste.take(6).map { it.toCard(badge = "Made for You") }
            )
        }

        val stationCards = buildList {
            byTaste.firstOrNull()?.let { seed ->
                add(HomeCardUi(
                    id = "station-taste",
                    title = userDisplayName?.let { "$it's Station" } ?: "Your Station",
                    subtitle = "Based on ${seed.artist}",
                    imageUrl = seed.thumbnailUrl
                ))
            }
            (trending.firstOrNull() ?: seeded.firstOrNull())?.let { seed ->
                add(HomeCardUi(id = "station-discovery", title = "Discovery Station", subtitle = "New and trending", imageUrl = seed.thumbnailUrl))
            }
        }
        if (stationCards.isNotEmpty()) {
            sections += HomeSection(
                id = "stations",
                header = HomeSectionHeader(title = "Stations for You", showChevron = false),
                style = HomeSectionStyle.LARGE_FEATURE_ROW,
                cards = stationCards
            )
        }

        return sections
    }

    private fun SongCandidate.toCard(badge: String? = null) =
        HomeCardUi(id = videoId, title = title, subtitle = artist, imageUrl = thumbnailUrl, badgeText = badge)
}
