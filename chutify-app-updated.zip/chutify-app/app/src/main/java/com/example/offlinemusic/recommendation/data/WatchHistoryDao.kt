package com.example.offlinemusic.recommendation.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.offlinemusic.recommendation.model.WatchHistoryEntity

@Dao
interface WatchHistoryDao {

    @Insert
    suspend fun recordPlay(entry: WatchHistoryEntity)

    @Query("SELECT COUNT(*) FROM watch_history")
    suspend fun totalPlays(): Int

    // Recency/frequency scoring happens in Kotlin (TasteProfileEngine) since
    // SQLite's exp() support varies by build — this just returns raw rows.
    @Query(
        """
        SELECT * FROM watch_history 
        WHERE playedAtEpochMillis >= :sinceEpochMillis 
        ORDER BY playedAtEpochMillis DESC
        """
    )
    suspend fun since(sinceEpochMillis: Long): List<WatchHistoryEntity>

    // Used by the ranker to avoid queueing something played a few minutes
    // ago. Deliberately just artist+title (no duration) — good enough for
    // "don't repeat this too soon" without the stricter library-dedup bar.
    @Query(
        """
        SELECT DISTINCT normalizedArtist || '|' || normalizedTitle 
        FROM watch_history 
        WHERE playedAtEpochMillis >= :sinceEpochMillis
        """
    )
    suspend fun recentlyPlayedKeys(sinceEpochMillis: Long): List<String>
}
