package com.example.offlinemusic.recommendation.engine

import com.example.offlinemusic.recommendation.model.SongCandidate
import com.example.offlinemusic.recommendation.model.TasteProfile
import java.time.Duration
import java.time.Instant

/**
 * Ranking stage — scores and orders what CandidateGenerator fetched.
 * Plain heuristics on purpose: fast, debuggable on a phone, and doesn't
 * need a training set the reference repo's MovieLens-trained weights
 * couldn't have supplied anyway.
 */
class SongRanker {

    fun rank(
        candidates: List<SongCandidate>,
        profile: TasteProfile,
        alreadyPlayedKeys: Set<String>, // format: "normalizedArtist|normalizedTitle" — see WatchHistoryDao
        limit: Int,
        maxPerArtist: Int = 3
    ): List<SongCandidate> {
        val affinityByArtist = profile.topArtists.associate { it.normalizedArtist to it.score }
        val maxAffinity = affinityByArtist.values.maxOrNull()?.takeIf { it > 0 } ?: 1.0

        val scored = candidates
            .filterNot { "${it.normalizedArtist}|${it.normalizedTitle}" in alreadyPlayedKeys }
            .map { candidate ->
                val affinityScore = (affinityByArtist[candidate.normalizedArtist] ?: 0.0) / maxAffinity
                val recencyScore = recencyBoost(candidate.publishedAt)
                val total = affinityScore * 0.7 + recencyScore * 0.3
                candidate to total
            }
            .sortedByDescending { it.second }

        // Diversity cap so the result isn't 10 songs from one artist in a row.
        val perArtistCount = mutableMapOf<String, Int>()
        val result = mutableListOf<SongCandidate>()
        for ((candidate, _) in scored) {
            val count = perArtistCount.getOrDefault(candidate.normalizedArtist, 0)
            if (count >= maxPerArtist) continue
            perArtistCount[candidate.normalizedArtist] = count + 1
            result += candidate
            if (result.size >= limit) break
        }
        return result
    }

    private fun recencyBoost(publishedAt: String?): Double {
        if (publishedAt.isNullOrBlank()) return 0.0
        return runCatching {
            val published = Instant.parse(publishedAt)
            val ageDays = Duration.between(published, Instant.now()).toDays()
            when {
                ageDays < 30 -> 1.0
                ageDays < 180 -> 0.6
                ageDays < 365 -> 0.3
                else -> 0.1
            }
        }.getOrDefault(0.0)
    }
}
