package com.example.offlinemusic.settings

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/**
 * Single source of truth for the YouTube Data API v3 key. Resolution order:
 *   1. A key pasted into Settings at runtime (stored here, in DataStore)
 *   2. buildTimeFallbackKey — pass BuildConfig.YOUTUBE_API_KEY in from
 *      wherever this is constructed (see README for the build.gradle setup
 *      that populates it from local.properties/CI secret, same as before)
 *
 * This class deliberately doesn't reference BuildConfig directly — that
 * would hard-fail compilation if the field isn't set up yet. Passing it in
 * as a plain nullable String keeps this class usable even before the
 * build-time plumbing exists.
 */
class ApiKeyRepository(
    private val dataStore: DataStore<Preferences>,
    private val buildTimeFallbackKey: String? = null
) {
    companion object {
        private val API_KEY = stringPreferencesKey("youtube_api_key")
    }

    val apiKeyFlow: Flow<String?> = dataStore.data.map { prefs ->
        prefs[API_KEY]?.takeIf { it.isNotBlank() }
            ?: buildTimeFallbackKey?.takeIf { it.isNotBlank() && it != "null" }
    }

    suspend fun getApiKey(): String? = apiKeyFlow.first()

    suspend fun hasRuntimeKey(): Boolean =
        dataStore.data.first()[API_KEY]?.isNotBlank() == true

    suspend fun setApiKey(key: String) {
        dataStore.edit { it[API_KEY] = key.trim() }
    }

    suspend fun clearRuntimeKey() {
        dataStore.edit { it.remove(API_KEY) }
    }
}
