package com.example.offlinemusic.home

data class HomeCardUi(
    val id: String, // videoId, or a synthetic id for station cards
    val title: String,
    val subtitle: String,
    val imageUrl: String,
    val badgeText: String? = null // small caption shown above the title on feature cards, e.g. "Made for You"
)

enum class HeaderImageShape { SQUARE, CIRCLE }

/** "More Like <X>" / "More From <Artist>" style header, or a plain section title when eyebrow/imageUrl are null. */
data class HomeSectionHeader(
    val eyebrow: String? = null,
    val title: String,
    val imageUrl: String? = null,
    val imageShape: HeaderImageShape = HeaderImageShape.SQUARE,
    val showChevron: Boolean = true
)

enum class HomeSectionStyle { SMALL_CAROUSEL, LARGE_FEATURE_ROW }

data class HomeSection(
    val id: String,
    val header: HomeSectionHeader,
    val style: HomeSectionStyle,
    val cards: List<HomeCardUi>
)

data class HomeUiState(
    val sections: List<HomeSection> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)
