package com.example.offlinemusic.recommendation.engine

import com.example.offlinemusic.recommendation.data.WatchHistoryDao
import com.example.offlinemusic.recommendation.model.ArtistAffinity
import com.example.offlinemusic.recommendation.model.TasteProfile
import kotlin.math.exp
import kotlin.math.ln

/**
 * Recency+frequency weighted taste profile — the on-device stand-in for the
 * reference paper's "example age" feature. A play from today counts far
 * more than one from three weeks ago, so taste drifts as listening habits
 * change instead of freezing on whatever was played most historically.
 */
class TasteProfileEngine(private val dao: WatchHistoryDao) {

    companion object {
        private const val HALF_LIFE_DAYS = 10.0 // an artist's weight halves every 10 days of inactivity
        private const val LOOKBACK_DAYS = 60L
        private const val MIN_PLAYS_FOR_WARM_START = 3
    }

    suspend fun buildProfile(nowEpochMillis: Long = System.currentTimeMillis()): TasteProfile {
        val sinceMillis = nowEpochMillis - LOOKBACK_DAYS * 24 * 60 * 60 * 1000
        val history = dao.since(sinceMillis)

        if (history.size < MIN_PLAYS_FOR_WARM_START) {
            return TasteProfile(topArtists = emptyList(), isColdStart = true)
        }

        val decayLambda = ln(2.0) / HALF_LIFE_DAYS

        val scores = history
            .groupBy { Triple(it.normalizedArtist, it.artist, it.channelId) }
            .map { (key, plays) ->
                val (normalizedArtist, artist, channelId) = key
                val score = plays.sumOf { play ->
                    val ageDays = (nowEpochMillis - play.playedAtEpochMillis) / 86_400_000.0
                    val completionBonus = if (play.completed) 1.0 else 0.4
                    exp(-decayLambda * ageDays) * completionBonus
                }
                ArtistAffinity(artist, normalizedArtist, channelId.ifBlank { null }, score)
            }
            .sortedByDescending { it.score }

        return TasteProfile(topArtists = scores, isColdStart = false)
    }
}
