package com.example.offlinemusic

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.offlinemusic.ui.MusicUiTokens

/** Stands in for New/Search/Library until those screens are built. */
@Composable
fun PlaceholderScreen(title: String) {
    Box(
        Modifier.fillMaxSize().background(MusicUiTokens.Background),
        contentAlignment = Alignment.Center
    ) {
        Text("$title — not built yet", color = MusicUiTokens.SecondaryText)
    }
}
