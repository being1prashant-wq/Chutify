package com.example.offlinemusic.home

/**
 * YouTube thumbnails are derivable from the videoId alone, so
 * WatchHistoryEntity (from the recommendation-engine module) doesn't need
 * its own thumbnailUrl column — this avoids a schema migration just for
 * the Home screen.
 */
object YouTubeThumbnails {
    fun url(videoId: String, quality: String = "mqdefault"): String =
        "https://i.ytimg.com/vi/$videoId/$quality.jpg"
}
