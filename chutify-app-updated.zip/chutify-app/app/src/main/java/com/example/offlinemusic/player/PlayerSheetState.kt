package com.example.offlinemusic.player

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer

/**
 * 0f = fully collapsed (mini player only), 1f = fully expanded (full player).
 * PlayerHost reads this to crossfade/scale between MiniPlayer and
 * ExpandedPlayer; the drag gesture in ExpandedPlayer writes to it directly
 * via snapTo while dragging, then settles it with expand()/collapse().
 *
 * Spring feel is tuned to be snappy-but-slightly-bouncy, matching the
 * reference Apple Music sheet behavior — note this isn't a literal number
 * translation from anything (React Native Reanimated's spring model uses
 * raw damping/stiffness/mass and isn't directly convertible to Compose's
 * dampingRatio/stiffness model), just tuned by feel to the same character.
 */
class PlayerSheetState(initialProgress: Float = 0f) {
    val expansionProgress = Animatable(initialProgress)

    val isExpanded: Boolean get() = expansionProgress.value > 0.5f

    suspend fun expand() {
        expansionProgress.animateTo(1f, spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow))
    }

    suspend fun collapse() {
        expansionProgress.animateTo(0f, spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMedium))
    }
}

@Composable
fun rememberPlayerSheetState(): PlayerSheetState = remember { PlayerSheetState() }

/**
 * Apply to the app's ROOT content Box (whatever wraps the NavHost/Scaffold)
 * to get the "background content shrinks slightly" effect Apple Music does
 * when the player sheet opens. Optional polish, not required for the
 * player itself to work — skip this modifier entirely if it's simpler to
 * wire in later.
 *
 * Reads expansionProgress inside the graphicsLayer lambda on purpose —
 * that defers the read to the draw phase, so the animation only triggers
 * redraw, not a full recomposition on every frame. Reading it eagerly
 * (e.g. via a plain .scale(computedValue) call) would recompose 60+ times
 * a second while the sheet is animating.
 */
fun Modifier.scaleWithPlayerSheet(sheetState: PlayerSheetState): Modifier = this.graphicsLayer {
    val scale = 1f - (sheetState.expansionProgress.value * 0.06f) // subtle ~6% shrink at full expansion
    scaleX = scale
    scaleY = scale
}
