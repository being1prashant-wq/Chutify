package com.example.offlinemusic.playback

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * The real WebView-backed PlayerBackend — loads
 * assets/youtube_player.html, which wraps the official YouTube IFrame
 * Player API. This is what actually produces sound; it supersedes the
 * WebViewPlayerBackendExample.kt sketch from the playback module (deleted
 * during assembly — this replaces it with matching JS call names).
 *
 * See PlaybackService's kdoc for the background-throttling caveats that
 * apply specifically to this WebView-based backend.
 */
@SuppressLint("SetJavaScriptEnabled")
class WebViewPlayerBackend(context: Context) : PlayerBackend {

    val webView: WebView = WebView(context.applicationContext).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        addJavascriptInterface(Bridge(), "AndroidBridge")
        loadUrl("file:///android_asset/youtube_player.html")
    }

    private var listener: PlayerBackendListener? = null
    private var lastKnownPositionMs = 0L
    private var lastKnownDurationMs = 0L
    private var playing = false
    private var pendingVideoId: String? = null
    private var pageReady = false

    override val isPlaying: Boolean get() = playing
    override val currentPositionMs: Long get() = lastKnownPositionMs
    override val durationMs: Long get() = lastKnownDurationMs

    override fun loadAndPlay(videoId: String) {
        pendingVideoId = videoId
        if (pageReady) {
            webView.post { webView.evaluateJavascript("loadVideo('$videoId');", null) }
        }
        // Helps keep JS timers alive once the app is backgrounded — one
        // piece of the throttling mitigation, not a complete fix on its own.
        webView.resumeTimers()
    }

    override fun play() {
        webView.post { webView.evaluateJavascript("player.playVideo();", null) }
    }

    override fun pause() {
        webView.post { webView.evaluateJavascript("player.pauseVideo();", null) }
    }

    override fun seekTo(positionMs: Long) {
        webView.post { webView.evaluateJavascript("player.seekTo(${positionMs / 1000.0}, true);", null) }
    }

    override fun release() {
        webView.evaluateJavascript("player.stopVideo();", null)
        webView.removeJavascriptInterface("AndroidBridge")
        webView.destroy()
    }

    override fun setListener(listener: PlayerBackendListener) {
        this.listener = listener
    }

    private inner class Bridge {
        @JavascriptInterface
        fun onReady() {
            pageReady = true
            pendingVideoId?.let { id -> webView.post { webView.evaluateJavascript("loadVideo('$id');", null) } }
        }

        @JavascriptInterface
        fun onStateChange(state: Int) {
            playing = state == 1
            listener?.onPlaybackStateChanged(playing)
            if (state == 0) listener?.onTrackEnded()
        }

        @JavascriptInterface
        fun onTimeUpdate(currentTimeSeconds: Double, durationSeconds: Double) {
            lastKnownPositionMs = (currentTimeSeconds * 1000).toLong()
            lastKnownDurationMs = (durationSeconds * 1000).toLong()
            listener?.onPositionChanged(lastKnownPositionMs, lastKnownDurationMs)
        }

        @JavascriptInterface
        fun onError(code: Int) {
            listener?.onError("YouTube player error $code")
        }
    }
}
