# Chutify — Assembled Project

Everything from the six modules delivered so far (recommendation engine,
background playback, home screen, player, queue, API key settings) merged
into one real Android Studio project, plus the glue that was missing:
`MainActivity`, a manual DI container, `PlayerViewModel`, Room database
setup, the actual YouTube IFrame HTML page + WebView backend, navigation,
Gradle project files, manifest, and a placeholder launcher icon.

## The one real gap: gradle-wrapper.jar
Every other wrapper file is here (`gradlew`, `gradlew.bat`,
`gradle-wrapper.properties`) but **not the wrapper jar itself** — it's a
compiled binary, and there's no way to produce a genuine one without either
downloading it or running Gradle locally, neither of which this environment
can do (no network access, no Gradle installed). Two ways to fix it, pick
whichever's easier:

**Option A — let the existing CI generate it.** GitHub's `ubuntu-latest`
runners ship with Gradle pre-installed. Add this step to the existing
workflow, right after "Locate Android project" and before "Verify Android
project":
```yaml
- name: Generate Gradle wrapper if missing
  shell: bash
  run: |
    cd "$PROJECT_DIR"
    if [ ! -f "gradle/wrapper/gradle-wrapper.jar" ]; then
      gradle wrapper --gradle-version 9.3.0
    fi
```
If that step fails with `gradle: command not found`, the runner image
changed since this was checked — swap it for the `gradle/actions/setup-gradle`
action instead, which provisions Gradle regardless of what's pre-installed.

**Option B — generate it once locally.** Since Android Studio bundles
Gradle, open the project there (it'll flag the missing wrapper), or from a
terminal with any Gradle available: `gradle wrapper --gradle-version 9.3.0`
from the project root. Commit the resulting `gradle/wrapper/gradle-wrapper.jar`
and it's a non-issue from then on.

## Version choices — please expect Android Studio to suggest updates
Kotlin 2.3.20, AGP 9.0.1, Gradle 9.3.0, Compose BOM 2026.04.01, compileSdk/
targetSdk 36, minSdk 26. These were checked against current versions as of
today rather than assumed from training data, since AGP crossed a major
version boundary (9.0 introduced built-in Kotlin compilation, replacing the
separate `kotlin-android` plugin) — `gradle.properties` explicitly opts out
of that (`android.builtInKotlin=false`) to keep the traditional plugin setup
this project actually uses. Secondary library versions (Room, Retrofit,
Coil, etc.) are reasonable-current best judgment, not individually
verified the way the core Kotlin/AGP/Compose stack was — if the build fails
on one of those specifically, bumping that single line is the likely fix.

## What's actually wired together
- Home screen loads real recommendations from the recommendation engine,
  tapping a card calls `PlaybackService.updateNowPlaying()` through
  `PlayerViewModel`, which also records watch history.
- The WebView backend is real — `assets/youtube_player.html` is a working
  YouTube IFrame Player API page, not a stub. Play/pause/seek/skip all
  reach it.
- Background playback + the notification are live once a song starts.
- Next/Previous do simple in-memory queue management (refills from
  `getQueueForSong()` when empty) — not a persisted queue.
- The API key Settings section isn't hooked into a nav route yet — it
  exists (`ApiKeySettingsSection`/`ApiKeySettingsScreen`) but nothing
  navigates to it. Easiest fix: add a `"settings"` composable route and a
  way to reach it (a gear icon somewhere, since Settings isn't one of the
  five bottom-nav tabs in the reference screenshots).

## Known simplifications (not bugs, just not built yet)
- New / Search / Library tabs are placeholder screens.
- Favorite status is in-memory only — no favorites table exists in any
  module, so it resets on process death.
- The Queue/History sheet exists but isn't wired to the queue icon yet —
  `onOpenQueue` in `ChutifyApp.kt` is an empty lambda with a comment showing
  where a `Boolean` show/hide state would go.
- Notification artwork isn't decoded to a `Bitmap` yet (`updateNowPlaying`
  is called with `artworkBitmap = null` in `PlayerViewModel`) — the
  notification will show without album art until that's wired up; the
  `ArtworkPalette` module's bitmap-loading logic is the natural thing to
  reuse for this.
- Bottom nav and a couple of small icons (queue drag handle, lyrics, cast)
  use plain text/shapes instead of Material icons — see the individual
  module READMEs for why (uncertainty about core vs. extended icon set).

## Sanity checks actually run (no compiler available here)
Every file was reviewed by hand; XML files were parsed to confirm they're
well-formed; brace/paren balance was checked on the newly-written glue
files; package references were grepped for consistency. None of that is a
substitute for an actual `./gradlew assembleDebug` run — please treat the
first real CI run as the actual test, and share the build log if it fails
on something specific.
