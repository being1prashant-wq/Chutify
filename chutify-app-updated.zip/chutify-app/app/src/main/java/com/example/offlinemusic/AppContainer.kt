package com.example.offlinemusic

import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Room
import com.example.offlinemusic.data.AppDatabase
import com.example.offlinemusic.playback.WebViewPlayerBackend
import com.example.offlinemusic.recommendation.data.SearchQuotaGuard
import com.example.offlinemusic.recommendation.engine.CandidateGenerator
import com.example.offlinemusic.recommendation.engine.RecommendationEngine
import com.example.offlinemusic.recommendation.engine.SongRanker
import com.example.offlinemusic.recommendation.engine.TasteProfileEngine
import com.example.offlinemusic.recommendation.network.YouTubeMusicApi
import com.example.offlinemusic.settings.ApiKeyRepository
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory

private val Context.dataStore by preferencesDataStore(name = "chutify_prefs")

/**
 * Manual DI — nothing here ever set up Hilt/Koin, so this is one plain
 * class constructing everything in dependency order, built once in
 * ChutifyApplication and handed to ViewModels via ViewModelFactory.
 */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val database: AppDatabase = Room.databaseBuilder(appContext, AppDatabase::class.java, "chutify.db").build()

    private val json = Json { ignoreUnknownKeys = true }
    private val okHttpClient = OkHttpClient.Builder().build()
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://www.googleapis.com/youtube/v3/")
        .client(okHttpClient)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()

    val youTubeMusicApi: YouTubeMusicApi = retrofit.create(YouTubeMusicApi::class.java)

    val apiKeyRepository = ApiKeyRepository(
        dataStore = appContext.dataStore,
        buildTimeFallbackKey = BuildConfig.YOUTUBE_API_KEY.takeIf { it.isNotBlank() && it != "null" }
    )

    private val searchQuotaGuard = SearchQuotaGuard(appContext.dataStore)
    private val candidateGenerator = CandidateGenerator(youTubeMusicApi, apiKeyRepository, searchQuotaGuard)
    private val tasteProfileEngine = TasteProfileEngine(database.watchHistoryDao())
    private val songRanker = SongRanker()

    val recommendationEngine = RecommendationEngine(
        dao = database.watchHistoryDao(),
        tasteProfileEngine = tasteProfileEngine,
        candidateGenerator = candidateGenerator,
        ranker = songRanker
    )

    // One WebView-backed player, owned here so it survives navigation/recomposition —
    // recreating a WebView per-composition would reload the page (and interrupt
    // playback) every time the screen recomposes.
    val webViewPlayerBackend: WebViewPlayerBackend by lazy { WebViewPlayerBackend(appContext) }
}
