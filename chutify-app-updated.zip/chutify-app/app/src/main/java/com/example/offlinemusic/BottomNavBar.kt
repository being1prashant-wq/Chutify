package com.example.offlinemusic

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.offlinemusic.ui.MusicUiTokens

private data class NavTab(val route: String, val label: String)

private val TABS = listOf(
    NavTab("home", "Home"),
    NavTab("new", "New"),
    NavTab("search", "Search"),
    NavTab("library", "Library")
)

/**
 * Text-label tabs rather than icons — same reasoning as the small header
 * chevron in the Home module: wasn't confident every icon needed here
 * (radio/waveform, grid, magnifier, stacked-music icons) is in the core
 * Material icon set. Swap in real icons whenever's convenient; the nav
 * logic itself doesn't depend on it.
 */
@Composable
fun BottomNavBar(navController: NavController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.hierarchy?.firstOrNull()?.route

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(MusicUiTokens.MiniPlayerBackground)
            .padding(horizontal = 8.dp)
    ) {
        TABS.forEach { tab ->
            val selected = currentRoute == tab.route
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clickable {
                        navController.navigate(tab.route) {
                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    tab.label,
                    color = if (selected) MusicUiTokens.Accent else MusicUiTokens.SecondaryText,
                    fontSize = 12.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.padding(top = 14.dp)
                )
            }
        }
    }
}
