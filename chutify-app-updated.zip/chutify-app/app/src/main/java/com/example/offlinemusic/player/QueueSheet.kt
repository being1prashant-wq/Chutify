package com.example.offlinemusic.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import com.example.offlinemusic.ui.MusicUiTokens
import kotlin.math.roundToInt

/**
 * Reachable from ExpandedPlayer's queue icon (onOpenQueue). The caller owns
 * the show/hide boolean and conditionally composes this — standard
 * ModalBottomSheet usage:
 *
 *   var showQueue by remember { mutableStateOf(false) }
 *   if (showQueue) QueueSheet(..., onDismiss = { showQueue = false })
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueSheet(
    nowPlaying: NowPlayingUi,
    isFavorite: Boolean,
    shuffleEnabled: Boolean,
    repeatMode: RepeatMode,
    autoplayEnabled: Boolean,
    historyItems: List<QueueItemUi>,
    continuePlayingItems: List<QueueItemUi>,
    onDismiss: () -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeatMode: () -> Unit,
    onToggleAutoplay: () -> Unit,
    onClearHistory: () -> Unit,
    onQueueItemClick: (QueueItemUi) -> Unit,
    onReorderContinuePlaying: (from: Int, to: Int) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MusicUiTokens.Background,
        contentColor = MusicUiTokens.PrimaryText
    ) {
        LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 640.dp)) {
            item { QueueHeaderRow(nowPlaying, isFavorite, onToggleFavorite) }
            item { Spacer(Modifier.height(16.dp)) }
            item { PlaybackModeRow(shuffleEnabled, repeatMode, autoplayEnabled, onToggleShuffle, onCycleRepeatMode, onToggleAutoplay) }
            item { Spacer(Modifier.height(24.dp)) }

            if (historyItems.isNotEmpty()) {
                item { SectionHeaderWithAction(title = "History", actionLabel = "Clear", onAction = onClearHistory) }
                items(historyItems, key = { "history-${it.id}" }) { item ->
                    QueueItemRow(item, onClick = { onQueueItemClick(item) }, showDragHandle = false)
                }
                item { Spacer(Modifier.height(20.dp)) }
            }

            item {
                Text(
                    "Continue Playing",
                    color = MusicUiTokens.PrimaryText,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = MusicUiTokens.ScreenPadding, vertical = 8.dp)
                )
            }
            // Plain Column, not further LazyColumn items — combining item
            // recycling with manual drag-reorder math gets complicated fast,
            // and a "continue playing" queue is rarely long enough for that
            // to matter. If it ever needs to hold hundreds of items, revisit.
            item {
                ReorderableQueueList(
                    items = continuePlayingItems,
                    onReorder = onReorderContinuePlaying,
                    onItemClick = onQueueItemClick
                )
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun QueueHeaderRow(nowPlaying: NowPlayingUi, isFavorite: Boolean, onToggleFavorite: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = MusicUiTokens.ScreenPadding, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = nowPlaying.artworkUrl,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(6.dp))
        )
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(nowPlaying.title, color = MusicUiTokens.PrimaryText, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(nowPlaying.artist, color = MusicUiTokens.SecondaryText, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onToggleFavorite) {
            Icon(
                if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = "Favorite",
                tint = MusicUiTokens.PrimaryText
            )
        }
        IconButton(onClick = { /* overflow menu — wire to whatever the app already uses */ }) {
            Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = MusicUiTokens.PrimaryText)
        }
    }
}

@Composable
private fun PlaybackModeRow(
    shuffleEnabled: Boolean,
    repeatMode: RepeatMode,
    autoplayEnabled: Boolean,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleAutoplay: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = MusicUiTokens.ScreenPadding),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ModePill(active = shuffleEnabled, onClick = onToggleShuffle, modifier = Modifier.weight(1f)) {
            Icon(Icons.Filled.Shuffle, contentDescription = "Shuffle", tint = it, modifier = Modifier.size(20.dp))
        }
        ModePill(active = repeatMode != RepeatMode.OFF, onClick = onCycleRepeat, modifier = Modifier.weight(1f)) {
            Icon(
                if (repeatMode == RepeatMode.ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                contentDescription = "Repeat",
                tint = it,
                modifier = Modifier.size(20.dp)
            )
        }
        ModePill(active = autoplayEnabled, onClick = onToggleAutoplay, modifier = Modifier.weight(1f)) {
            // Plain glyph, not a Material icon — less confident "infinity/autoplay"
            // is in the core icon set rather than the extended one.
            Text("\u221E", color = it, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ModePill(
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable (tint: androidx.compose.ui.graphics.Color) -> Unit
) {
    val tint = if (active) MusicUiTokens.Accent else MusicUiTokens.PrimaryText.copy(alpha = 0.6f)
    val background = if (active) MusicUiTokens.Accent.copy(alpha = 0.15f) else MusicUiTokens.MiniPlayerBackground
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content(tint)
    }
}

@Composable
private fun SectionHeaderWithAction(title: String, actionLabel: String, onAction: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = MusicUiTokens.ScreenPadding, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = MusicUiTokens.PrimaryText, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(
            actionLabel,
            color = MusicUiTokens.Accent,
            fontSize = 14.sp,
            modifier = Modifier.clickable(onClick = onAction)
        )
    }
}

@Composable
private fun QueueItemRow(
    item: QueueItemUi,
    onClick: () -> Unit,
    showDragHandle: Boolean,
    modifier: Modifier = Modifier,
    dragHandleModifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = MusicUiTokens.ScreenPadding, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = item.artworkUrl,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(6.dp))
        )
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(item.title, color = MusicUiTokens.PrimaryText, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(item.subtitle, color = MusicUiTokens.SecondaryText, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (showDragHandle) {
            DragHandleGlyph(modifier = Modifier.padding(start = 8.dp).then(dragHandleModifier))
        }
    }
}

@Composable
private fun DragHandleGlyph(modifier: Modifier = Modifier) {
    // Drawn manually rather than a Material icon (e.g. Icons.Filled.DragHandle)
    // — wasn't confident that specific one is in the core icon set.
    Column(modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        repeat(3) {
            Box(Modifier.width(20.dp).height(2.dp).background(MusicUiTokens.SecondaryText, RoundedCornerShape(1.dp)))
        }
    }
}

/**
 * Simple drag-to-reorder: track one dragged index + its accumulated offset,
 * compute a target index whenever the offset crosses a full item-height
 * step, fire onReorder immediately, then rebase. This is a starting point —
 * untested on a real device — expect to tune feel/thresholds once tried.
 * Uses a plain Column (see the item {} comment in QueueSheet above).
 */
@Composable
private fun ReorderableQueueList(
    items: List<QueueItemUi>,
    onReorder: (from: Int, to: Int) -> Unit,
    onItemClick: (QueueItemUi) -> Unit
) {
    val density = LocalDensity.current
    val itemHeight: Dp = 64.dp
    val itemHeightPx = with(density) { itemHeight.toPx() }

    var draggedIndex by remember { mutableIntStateOf(-1) }
    var dragOffsetPx by remember { mutableFloatStateOf(0f) }

    Column {
        items.forEachIndexed { index, item ->
            val isDragging = index == draggedIndex
            QueueItemRow(
                item = item,
                onClick = { if (draggedIndex == -1) onItemClick(item) },
                showDragHandle = true,
                modifier = Modifier
                    .height(itemHeight)
                    .graphicsLayer {
                        translationY = if (isDragging) dragOffsetPx else 0f
                    }
                    .zIndex(if (isDragging) 1f else 0f),
                dragHandleModifier = Modifier.pointerInput(index, items.size) {
                    detectDragGestures(
                        onDragStart = { draggedIndex = index; dragOffsetPx = 0f },
                        onDragEnd = { draggedIndex = -1; dragOffsetPx = 0f },
                        onDragCancel = { draggedIndex = -1; dragOffsetPx = 0f },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            dragOffsetPx += dragAmount.y
                            val steps = (dragOffsetPx / itemHeightPx).roundToInt()
                            if (steps != 0) {
                                val targetIndex = (draggedIndex + steps).coerceIn(0, items.lastIndex)
                                if (targetIndex != draggedIndex) {
                                    onReorder(draggedIndex, targetIndex)
                                    dragOffsetPx -= steps * itemHeightPx
                                    draggedIndex = targetIndex
                                }
                            }
                        }
                    )
                }
            )
        }
    }
}
