package com.example.offlinemusic.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.offlinemusic.recommendation.network.YouTubeMusicApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ApiKeyTestResult { NONE, SUCCESS, FAILURE }

data class ApiKeySettingsUiState(
    val inputText: String = "",
    val isUsingRuntimeKey: Boolean = false,
    val isUsingBuildTimeKey: Boolean = false,
    val testResult: ApiKeyTestResult = ApiKeyTestResult.NONE,
    val isTesting: Boolean = false
)

class ApiKeySettingsViewModel(
    private val repository: ApiKeyRepository,
    private val api: YouTubeMusicApi
) : ViewModel() {

    private val _uiState = MutableStateFlow(ApiKeySettingsUiState())
    val uiState: StateFlow<ApiKeySettingsUiState> = _uiState

    init {
        viewModelScope.launch {
            val hasRuntimeKey = repository.hasRuntimeKey()
            val currentKey = repository.getApiKey()
            _uiState.update {
                it.copy(
                    inputText = if (hasRuntimeKey) currentKey.orEmpty() else "",
                    isUsingRuntimeKey = hasRuntimeKey,
                    isUsingBuildTimeKey = !hasRuntimeKey && currentKey != null
                )
            }
        }
    }

    fun onInputChanged(text: String) {
        _uiState.update { it.copy(inputText = text, testResult = ApiKeyTestResult.NONE) }
    }

    fun save() {
        viewModelScope.launch {
            repository.setApiKey(_uiState.value.inputText)
            _uiState.update { it.copy(isUsingRuntimeKey = true, isUsingBuildTimeKey = false) }
        }
    }

    fun clearRuntimeKey() {
        viewModelScope.launch {
            repository.clearRuntimeKey()
            val fallback = repository.getApiKey()
            _uiState.update {
                it.copy(inputText = "", isUsingRuntimeKey = false, isUsingBuildTimeKey = fallback != null, testResult = ApiKeyTestResult.NONE)
            }
        }
    }

    /** Tests whatever's currently typed — doesn't require Save first, so a bad key can be caught before committing it. */
    fun test() {
        val key = _uiState.value.inputText.trim()
        if (key.isBlank()) {
            _uiState.update { it.copy(testResult = ApiKeyTestResult.FAILURE) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isTesting = true, testResult = ApiKeyTestResult.NONE) }
            // Cheap call (1 quota unit) just to confirm the key is accepted —
            // not a search.list call, so this doesn't touch the tight
            // search quota from the recommendation-engine module.
            val success = runCatching { api.mostPopularMusic(apiKey = key) }.isSuccess
            _uiState.update { it.copy(isTesting = false, testResult = if (success) ApiKeyTestResult.SUCCESS else ApiKeyTestResult.FAILURE) }
        }
    }
}
