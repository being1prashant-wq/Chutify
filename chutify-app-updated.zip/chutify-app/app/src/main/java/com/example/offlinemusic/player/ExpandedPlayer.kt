package com.example.offlinemusic.player

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.offlinemusic.ui.MusicUiTokens
import kotlinx.coroutines.launch
import kotlin.math.roundToLong

@Composable
fun ExpandedPlayer(
    state: PlayerUiState,
    sheetState: PlayerSheetState,
    onPlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleFavorite: () -> Unit,
    onOpenQueue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val nowPlaying = state.nowPlaying ?: return
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var gradientColors by remember { mutableStateOf(ArtworkPalette.DefaultColors) }
    LaunchedEffect(nowPlaying.videoId) {
        gradientColors = ArtworkPalette.extractGradient(context, nowPlaying.artworkUrl)
    }
    val topColor by animateColorAsState(gradientColors.first, label = "gradientTop")
    val bottomColor by animateColorAsState(gradientColors.second, label = "gradientBottom")

    // Drag-to-dismiss. dragAccumPx is plain (non-animated) state for a 1:1
    // live feel while actively dragging; expansionProgress only takes over
    // for the settle animation on release. A starting point, not pixel-tuned
    // — expect to adjust dismissThresholdPx once tested on a real device.
    val density = LocalDensity.current
    val dismissThresholdPx = with(density) { 140.dp.toPx() }
    var dragAccumPx by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(topColor, bottomColor)))
            .clip(RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp))
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { dragAccumPx = 0f },
                    onDragEnd = {
                        scope.launch {
                            if (dragAccumPx > dismissThresholdPx) sheetState.collapse() else sheetState.expand()
                        }
                    },
                    onDragCancel = { scope.launch { sheetState.expand() } },
                    onVerticalDrag = { change, dragAmount ->
                        change.consume()
                        if (dragAmount > 0f || dragAccumPx > 0f) {
                            dragAccumPx = (dragAccumPx + dragAmount).coerceAtLeast(0f)
                            scope.launch {
                                sheetState.expansionProgress.snapTo(1f - (dragAccumPx / dismissThresholdPx).coerceIn(0f, 1f))
                            }
                        }
                    }
                )
            }
            .padding(top = 12.dp, start = 24.dp, end = 24.dp, bottom = 24.dp)
    ) {
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .size(width = 40.dp, height = 5.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(Color.White.copy(alpha = 0.45f))
        )

        Spacer(Modifier.weight(1f))

        AsyncImage(
            model = nowPlaying.artworkUrl,
            contentDescription = nowPlaying.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .shadow(elevation = 24.dp, shape = RoundedCornerShape(8.dp), ambientColor = Color.Black.copy(alpha = 0.4f))
                .clip(RoundedCornerShape(8.dp))
        )

        Spacer(Modifier.height(28.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    nowPlaying.title,
                    color = MusicUiTokens.PrimaryText,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    nowPlaying.artist,
                    color = MusicUiTokens.PrimaryText.copy(alpha = 0.7f),
                    fontSize = 19.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onToggleFavorite) {
                Icon(
                    if (state.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = MusicUiTokens.PrimaryText
                )
            }
            IconButton(onClick = { /* overflow menu — wire to whatever the app already uses */ }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = MusicUiTokens.PrimaryText)
            }
        }

        Spacer(Modifier.height(16.dp))

        PlayerProgressBar(state = state, onSeek = onSeek)

        Spacer(Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onSkipPrevious, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = MusicUiTokens.PrimaryText, modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = onPlayPause, modifier = Modifier.size(64.dp)) {
                Icon(
                    if (state.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (state.isPlaying) "Pause" else "Play",
                    tint = MusicUiTokens.PrimaryText,
                    modifier = Modifier.size(52.dp) // ~1.2x the side controls, matching the reference's emphasis on the center button
                )
            }
            IconButton(onClick = onSkipNext, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = MusicUiTokens.PrimaryText, modifier = Modifier.size(36.dp))
            }
        }

        Spacer(Modifier.weight(1f))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onClick = { /* lyrics — separate view, not built here */ }) {
                Text("\u201C\u201D", color = MusicUiTokens.PrimaryText.copy(alpha = 0.8f), fontSize = 20.sp) // lyrics placeholder glyph
            }
            IconButton(onClick = { /* cast/output picker — no AirPlay equivalent on Android; wire to a device-output picker if wanted */ }) {
                Text("\u25C8", color = MusicUiTokens.PrimaryText.copy(alpha = 0.8f), fontSize = 18.sp) // cast placeholder glyph
            }
            IconButton(onClick = onOpenQueue) {
                Icon(Icons.Filled.List, contentDescription = "Queue", tint = MusicUiTokens.PrimaryText.copy(alpha = 0.8f))
            }
        }
    }
}

@Composable
private fun PlayerProgressBar(state: PlayerUiState, onSeek: (Long) -> Unit) {
    val progress = if (state.durationMs > 0) (state.positionMs.toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f
    var barWidthPx by remember { mutableFloatStateOf(0f) }

    Column {
        Box(
            Modifier
                .fillMaxWidth()
                .height(6.dp)
                .onGloballyPositioned { barWidthPx = it.size.width.toFloat() }
                .clip(RoundedCornerShape(5.dp))
                .background(Color.White.copy(alpha = 0.3f))
                .pointerInput(state.durationMs, barWidthPx) {
                    detectTapGestures { offset ->
                        if (barWidthPx > 0f && state.durationMs > 0) {
                            val fraction = (offset.x / barWidthPx).coerceIn(0f, 1f)
                            onSeek((fraction * state.durationMs).roundToLong())
                        }
                    }
                }
        ) {
            Box(
                Modifier
                    .fillMaxWidth(progress)
                    .height(6.dp)
                    .background(
                        Color.White.copy(alpha = 0.7f),
                        RoundedCornerShape(topStart = 5.dp, bottomStart = 5.dp, topEnd = 0.dp, bottomEnd = 0.dp)
                    )
            )
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatMs(state.positionMs), color = MusicUiTokens.SecondaryText, fontSize = 12.sp)
            Text("-" + formatMs((state.durationMs - state.positionMs).coerceAtLeast(0)), color = MusicUiTokens.SecondaryText, fontSize = 12.sp)
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSeconds = (ms / 1000.0).roundToLong()
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
