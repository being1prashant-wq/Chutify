package com.example.offlinemusic.recommendation.engine

import com.example.offlinemusic.recommendation.data.SearchQuotaGuard
import com.example.offlinemusic.recommendation.model.SongCandidate
import com.example.offlinemusic.recommendation.model.TasteProfile
import com.example.offlinemusic.recommendation.network.YouTubeMusicApi
import com.example.offlinemusic.settings.ApiKeyRepository

/**
 * PATCH — replaces the CandidateGenerator.kt delivered with the
 * recommendation-engine module. Only real change: the constructor took a
 * fixed `apiKey: String` before; now it takes ApiKeyRepository and resolves
 * the key at the start of each call. That's what makes a key pasted into
 * Settings take effect immediately, without recreating this class or
 * restarting the app. If no key is available at all (nothing saved, no
 * build-time key either), each method just returns an empty list rather
 * than crashing — the UI layer should show something sensible for that
 * (the ApiKeySettingsSection's status line already explains why).
 *
 * Everything else — the cheapest-endpoint-first ordering, the quota guard
 * usage, the candidate-mapping calls — is unchanged from the original.
 */
class CandidateGenerator(
    private val api: YouTubeMusicApi,
    private val apiKeyRepository: ApiKeyRepository,
    private val quotaGuard: SearchQuotaGuard
) {

    private val uploadsPlaylistCache = mutableMapOf<String, String>()

    suspend fun coldStartCandidates(): List<SongCandidate> {
        val apiKey = apiKeyRepository.getApiKey() ?: return emptyList()

        val fromChart = runCatching {
            api.mostPopularMusic(apiKey = apiKey).items.mapNotNull { it.toCandidate("trending-IN") }
        }.getOrDefault(emptyList())

        val fromSeeds = if (quotaGuard.canSearch()) {
            PunjabiSeedQueries.SEED_ARTISTS.take(3).flatMap { artist ->
                quotaGuard.recordSearchCall()
                runCatching {
                    api.search(query = artist, apiKey = apiKey).items.mapNotNull { it.toCandidate("seed:$artist") }
                }.getOrDefault(emptyList())
            }
        } else emptyList()

        return (fromChart + fromSeeds).distinctBy { it.videoId }
    }

    suspend fun homeCandidates(profile: TasteProfile): List<SongCandidate> {
        if (profile.isColdStart) return coldStartCandidates()
        val apiKey = apiKeyRepository.getApiKey() ?: return emptyList()

        val results = mutableListOf<SongCandidate>()
        for (affinity in profile.topArtists.take(5)) {
            results += candidatesForArtist(apiKey, affinity.artist, affinity.channelId, reason = "taste:${affinity.artist}")
        }
        results += runCatching {
            api.mostPopularMusic(apiKey = apiKey).items.mapNotNull { it.toCandidate("trending-IN") }
        }.getOrDefault(emptyList())

        return results.distinctBy { it.videoId }
    }

    suspend fun queueCandidates(currentChannelId: String, currentArtist: String): List<SongCandidate> {
        val apiKey = apiKeyRepository.getApiKey() ?: return emptyList()
        return candidatesForArtist(apiKey, currentArtist, currentChannelId, reason = "queue:$currentArtist")
    }

    private suspend fun candidatesForArtist(apiKey: String, artist: String, channelId: String?, reason: String): List<SongCandidate> {
        val fromChannel = channelId?.takeIf { it.isNotBlank() }?.let { id ->
            runCatching {
                val uploadsPlaylistId = uploadsPlaylistCache[id] ?: run {
                    val resolved = api.channel(id, apiKey = apiKey).items
                        .firstOrNull()?.contentDetails?.relatedPlaylists?.uploads
                    if (resolved != null) uploadsPlaylistCache[id] = resolved
                    resolved
                }
                if (uploadsPlaylistId.isNullOrBlank()) emptyList()
                else api.playlistItems(uploadsPlaylistId, apiKey = apiKey).items.mapNotNull { it.toCandidate(reason) }
            }.getOrDefault(emptyList())
        } ?: emptyList()

        if (fromChannel.size >= 8) return fromChannel

        val fromSearch = if (quotaGuard.canSearch()) {
            quotaGuard.recordSearchCall()
            runCatching {
                api.search(query = artist, apiKey = apiKey).items.mapNotNull { it.toCandidate(reason) }
            }.getOrDefault(emptyList())
        } else emptyList()

        return (fromChannel + fromSearch).distinctBy { it.videoId }
    }
}
