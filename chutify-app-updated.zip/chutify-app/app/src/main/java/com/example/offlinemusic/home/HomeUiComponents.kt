package com.example.offlinemusic.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

// Assumes coil-compose is already a dependency (near-certain, given the
// app already renders YouTube thumbnails elsewhere). Swap AsyncImage below
// for whatever image loader is already in use if it's not Coil.

@Composable
fun HomeSectionHeaderRow(header: HomeSectionHeader, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = MusicUiTokens.ScreenPadding, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        header.imageUrl?.let { url ->
            AsyncImage(
                model = url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(44.dp)
                    .clip(if (header.imageShape == HeaderImageShape.CIRCLE) CircleShape else RoundedCornerShape(6.dp))
            )
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            header.eyebrow?.let {
                Text(it, color = MusicUiTokens.SecondaryText, fontSize = 14.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    header.title,
                    color = MusicUiTokens.PrimaryText,
                    fontSize = if (header.eyebrow != null) 22.sp else 20.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (header.showChevron) {
                    Text(
                        " \u203A", // simple chevron glyph — avoids depending on the extended Material icon set
                        color = MusicUiTokens.SecondaryText,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun AlbumCard(card: HomeCardUi, modifier: Modifier = Modifier, onClick: (HomeCardUi) -> Unit = {}) {
    Column(modifier = modifier.width(150.dp).clickable { onClick(card) }) {
        AsyncImage(
            model = card.imageUrl,
            contentDescription = card.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(150.dp)
                .clip(RoundedCornerShape(MusicUiTokens.SmallCardCorner))
        )
        Spacer(Modifier.height(8.dp))
        Text(card.title, color = MusicUiTokens.PrimaryText, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(card.subtitle, color = MusicUiTokens.SecondaryText, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun FeatureCard(card: HomeCardUi, modifier: Modifier = Modifier, onClick: (HomeCardUi) -> Unit = {}) {
    Box(
        modifier = modifier
            .width(280.dp)
            .height(320.dp)
            .clip(RoundedCornerShape(MusicUiTokens.LargeCardCorner))
            .clickable { onClick(card) }
    ) {
        AsyncImage(
            model = card.imageUrl,
            contentDescription = card.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(320.dp)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomStart)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))))
                .padding(16.dp)
        ) {
            Column {
                card.badgeText?.let {
                    Text(it, color = MusicUiTokens.PrimaryText.copy(alpha = 0.8f), fontSize = 13.sp)
                }
                Text(card.title, color = MusicUiTokens.PrimaryText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    card.subtitle,
                    color = MusicUiTokens.PrimaryText.copy(alpha = 0.85f),
                    fontSize = 14.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun HomeSectionView(section: HomeSection, onCardClick: (HomeCardUi) -> Unit) {
    Column {
        HomeSectionHeaderRow(section.header)
        LazyRow(
            contentPadding = PaddingValues(horizontal = MusicUiTokens.ScreenPadding),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(section.cards, key = { it.id }) { card ->
                when (section.style) {
                    HomeSectionStyle.SMALL_CAROUSEL -> AlbumCard(card, onClick = onCardClick)
                    HomeSectionStyle.LARGE_FEATURE_ROW -> FeatureCard(card, onClick = onCardClick)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
