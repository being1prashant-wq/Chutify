package com.example.offlinemusic.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.offlinemusic.ui.MusicUiTokens

/**
 * Drop this into an existing Settings screen as one section, or use
 * ApiKeySettingsScreen below as a standalone screen if there isn't one yet.
 */
@Composable
fun ApiKeySettingsSection(
    uiState: ApiKeySettingsUiState,
    onInputChanged: (String) -> Unit,
    onSave: () -> Unit,
    onClear: () -> Unit,
    onTest: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showKey by remember { mutableStateOf(false) }

    Column(modifier.fillMaxWidth().padding(MusicUiTokens.ScreenPadding)) {
        Text("YouTube API Key", color = MusicUiTokens.PrimaryText, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(statusLine(uiState), color = MusicUiTokens.SecondaryText, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = uiState.inputText,
            onValueChange = onInputChanged,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
            placeholder = { Text("AIza...") },
            trailingIcon = {
                TextButton(onClick = { showKey = !showKey }) {
                    Text(if (showKey) "Hide" else "Show", fontSize = 12.sp, color = MusicUiTokens.SecondaryText)
                }
            }
        )

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onSave, enabled = uiState.inputText.isNotBlank()) {
                Text("Save")
            }
            OutlinedButton(onClick = onTest, enabled = uiState.inputText.isNotBlank() && !uiState.isTesting) {
                if (uiState.isTesting) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MusicUiTokens.Accent)
                } else {
                    Text("Test")
                }
            }
            if (uiState.isUsingRuntimeKey) {
                TextButton(onClick = onClear) { Text("Clear") }
            }
        }

        when (uiState.testResult) {
            ApiKeyTestResult.SUCCESS -> {
                Spacer(Modifier.height(8.dp))
                Text("Key works", color = Color(0xFF34C759), fontSize = 13.sp)
            }
            ApiKeyTestResult.FAILURE -> {
                Spacer(Modifier.height(8.dp))
                Text("Couldn't verify — check the key, or that YouTube Data API v3 is enabled on it", color = MusicUiTokens.Accent, fontSize = 13.sp)
            }
            ApiKeyTestResult.NONE -> {}
        }
    }
}

private fun statusLine(state: ApiKeySettingsUiState): String = when {
    state.isUsingRuntimeKey -> "Using the key saved here."
    state.isUsingBuildTimeKey -> "Using the build-time key. Paste one below to override it for this device."
    else -> "No key configured — the app can't reach YouTube until one is set here or at build time."
}

/** Standalone screen, for use before a real Settings destination exists. */
@Composable
fun ApiKeySettingsScreen(viewModel: ApiKeySettingsViewModel, modifier: Modifier = Modifier) {
    val uiState by viewModel.uiState.collectAsState()
    Column(modifier.fillMaxWidth()) {
        Text(
            "Settings",
            color = MusicUiTokens.PrimaryText,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(MusicUiTokens.ScreenPadding)
        )
        ApiKeySettingsSection(
            uiState = uiState,
            onInputChanged = viewModel::onInputChanged,
            onSave = viewModel::save,
            onClear = viewModel::clearRuntimeKey,
            onTest = viewModel::test
        )
    }
}
