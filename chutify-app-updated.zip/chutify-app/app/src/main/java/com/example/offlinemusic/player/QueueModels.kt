package com.example.offlinemusic.player

data class QueueItemUi(
    val id: String, // videoId
    val title: String,
    val subtitle: String,
    val artworkUrl: String
)

enum class RepeatMode { OFF, ALL, ONE }
