package com.example.offlinemusic.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette
import coil.imageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Requires androidx.palette:palette-ktx as a new dependency (not something
 * a YouTube-thumbnail-only app would already have pulled in). Coil is
 * assumed for image loading, same as the Home screen module.
 */
object ArtworkPalette {

    val DefaultColors = Color(0xFF1C1C1E) to Color(0xFF000000)

    /** Dominant color + a darkened variant, for the two-stop gradient — mirrors the reference app's shadeColor(color, -50) approach. */
    suspend fun extractGradient(context: Context, artworkUrl: String): Pair<Color, Color> {
        val bitmap = loadBitmap(context, artworkUrl) ?: return DefaultColors
        return withContext(Dispatchers.Default) {
            val palette = Palette.from(bitmap).generate()
            val base = palette.vibrantSwatch?.rgb
                ?: palette.mutedSwatch?.rgb
                ?: palette.dominantSwatch?.rgb
                ?: DefaultColors.first.toArgb()
            val baseColor = Color(base)
            baseColor to darken(baseColor, 0.5f)
        }
    }

    private suspend fun loadBitmap(context: Context, url: String): Bitmap? = withContext(Dispatchers.IO) {
        runCatching {
            val request = ImageRequest.Builder(context)
                .data(url)
                .allowHardware(false) // Palette needs to read pixels — hardware bitmaps can't be read directly
                .build()
            val result = context.imageLoader.execute(request)
            (result.drawable as? BitmapDrawable)?.bitmap
        }.getOrNull()
    }

    private fun darken(color: Color, factor: Float): Color {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(color.toArgb(), hsv)
        hsv[2] = (hsv[2] * (1f - factor)).coerceIn(0f, 1f)
        return Color(android.graphics.Color.HSVToColor(hsv))
    }
}
