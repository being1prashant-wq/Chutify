package com.example.offlinemusic.recommendation.model

data class ArtistAffinity(
    val artist: String,
    val normalizedArtist: String,
    val channelId: String?,
    val score: Double // recency + frequency weighted — see TasteProfileEngine
)

data class TasteProfile(
    val topArtists: List<ArtistAffinity>,
    val isColdStart: Boolean // true when there isn't enough history yet
)
