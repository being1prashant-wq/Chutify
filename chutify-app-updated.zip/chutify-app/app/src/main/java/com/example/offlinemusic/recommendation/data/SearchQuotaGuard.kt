package com.example.offlinemusic.recommendation.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import kotlinx.coroutines.flow.first
import java.util.Calendar
import java.util.TimeZone

/**
 * search.list costs 100 of the project's 10,000 daily quota units — as few
 * as 100 calls exhausts the ENTIRE app's quota for EVERY install, since the
 * build ships one shared key (per the existing local.properties/GitHub
 * Secrets setup). Without a limiter, one busy day means quotaExceeded (403)
 * for every user until midnight Pacific.
 *
 * This self-limits search.list calls well below Google's own cap, so a busy
 * day degrades to the cheap chart/playlistItems fallbacks in
 * CandidateGenerator instead of the app breaking for everyone.
 *
 * If Chutify ever moves to per-user API keys (each install supplies its
 * own), this guard can be relaxed a lot — it's only this conservative
 * because the quota pool is shared.
 */
class SearchQuotaGuard(private val dataStore: DataStore<Preferences>) {

    companion object {
        private const val SEARCH_CALLS_PER_DAY_LIMIT = 60 // stay well under Google's 100
        private val COUNT_KEY = intPreferencesKey("yt_search_calls_today")
        private val DAY_KEY = longPreferencesKey("yt_search_calls_day_marker")
    }

    private fun pacificDayMarker(): Long {
        // Quota resets at midnight Pacific, not local time.
        val cal = Calendar.getInstance(TimeZone.getTimeZone("America/Los_Angeles"))
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    suspend fun canSearch(): Boolean {
        val prefs = dataStore.data.first()
        val today = pacificDayMarker()
        val storedDay = prefs[DAY_KEY] ?: 0L
        val count = if (storedDay == today) prefs[COUNT_KEY] ?: 0 else 0
        return count < SEARCH_CALLS_PER_DAY_LIMIT
    }

    suspend fun recordSearchCall() {
        val today = pacificDayMarker()
        dataStore.edit { prefs ->
            val storedDay = prefs[DAY_KEY] ?: 0L
            val count = if (storedDay == today) prefs[COUNT_KEY] ?: 0 else 0
            prefs[DAY_KEY] = today
            prefs[COUNT_KEY] = count + 1
        }
    }
}
