package com.example.offlinemusic.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Home tab CONTENT only — the scrollable section list. Place this inside
 * the existing Scaffold/NavHost, below whatever top bar is used and above
 * the already-built mini player + bottom nav; this composable doesn't own
 * either of those, on purpose, to avoid touching what's already working.
 */
@Composable
fun HomeScreen(
    uiState: HomeUiState,
    onCardClick: (HomeCardUi) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier.fillMaxSize().background(MusicUiTokens.Background)) {
        when {
            uiState.isLoading && uiState.sections.isEmpty() -> {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center),
                    color = MusicUiTokens.Accent
                )
            }
            uiState.errorMessage != null && uiState.sections.isEmpty() -> {
                Text(
                    uiState.errorMessage,
                    color = MusicUiTokens.SecondaryText,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
            else -> LazyColumn {
                items(uiState.sections, key = { it.id }) { section ->
                    HomeSectionView(section, onCardClick)
                }
                item { Spacer(Modifier.height(24.dp)) } // breathing room above the mini player
            }
        }
    }
}
