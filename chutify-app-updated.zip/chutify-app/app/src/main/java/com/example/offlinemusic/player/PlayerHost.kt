package com.example.offlinemusic.player

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.launch

/**
 * Place this near the root of the screen that hosts the bottom nav (above
 * it in z-order, below any system bars). Both children read
 * sheetState.expansionProgress directly inside graphicsLayer blocks, so
 * only redraw — not full recomposition — happens as the value animates.
 *
 * Each child is only actually composed (not just invisible) outside its
 * relevant progress range, so neither intercepts touches meant for the
 * other side once the transition settles.
 */
@Composable
fun PlayerHost(
    uiState: PlayerUiState,
    sheetState: PlayerSheetState,
    onPlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleFavorite: () -> Unit,
    onOpenQueue: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (uiState.nowPlaying == null) return
    val scope = rememberCoroutineScope()
    val progress = sheetState.expansionProgress.value

    Box(modifier.fillMaxSize()) {
        if (progress < 0.99f) {
            MiniPlayer(
                state = uiState,
                onTap = { scope.launch { sheetState.expand() } },
                onPlayPause = onPlayPause,
                onSkipNext = onSkipNext,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .graphicsLayer { alpha = 1f - sheetState.expansionProgress.value }
            )
        }
        if (progress > 0.01f) {
            ExpandedPlayer(
                state = uiState,
                sheetState = sheetState,
                onPlayPause = onPlayPause,
                onSkipNext = onSkipNext,
                onSkipPrevious = onSkipPrevious,
                onSeek = onSeek,
                onToggleFavorite = onToggleFavorite,
                onOpenQueue = onOpenQueue,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .graphicsLayer {
                        alpha = sheetState.expansionProgress.value
                        translationY = (1f - sheetState.expansionProgress.value) * size.height * 0.15f
                    }
            )
        }
    }
}
