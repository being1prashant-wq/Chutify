package com.example.offlinemusic.data

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.offlinemusic.recommendation.data.WatchHistoryDao
import com.example.offlinemusic.recommendation.model.WatchHistoryEntity

@Database(entities = [WatchHistoryEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun watchHistoryDao(): WatchHistoryDao
}
